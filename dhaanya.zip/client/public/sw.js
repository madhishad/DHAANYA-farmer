const CACHE_NAME = "dhaanya-shell-v2";
const APP_SHELL = ["/", "/manifest.webmanifest", "/dhaanya-icon.svg"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.pathname.startsWith("/api/") || url.pathname.includes("identity") || url.pathname.includes("payment")) return;
  if (request.mode === "navigate") {
    event.respondWith(fetch(request).then((response) => { const copy = response.clone(); caches.open(CACHE_NAME).then((cache) => cache.put(request, copy)); return response; }).catch(() => caches.match(request).then((cached) => cached || caches.match("/"))));
    return;
  }
  event.respondWith(caches.match(request).then((cached) => cached || fetch(request).then((response) => { const copy = response.clone(); caches.open(CACHE_NAME).then((cache) => cache.put(request, copy)); return response; })));
});
self.addEventListener("sync", (event) => { if (event.tag === "dhaanya-safe-sync") event.waitUntil(self.clients.matchAll().then((clients) => clients.forEach((client) => client.postMessage({ type: "DHAANYA_SYNC_REQUEST" })))); });
self.addEventListener("push", (event) => { if (!event.data) return; const data = event.data.json(); event.waitUntil(self.registration.showNotification(data.title || "Dhaanya", { body: data.body || "", data: { destination: data.destination || "/farmer/dashboard" }, icon: "/dhaanya-icon.svg" })); });
self.addEventListener("notificationclick", (event) => { event.notification.close(); event.waitUntil(self.clients.openWindow(event.notification.data?.destination || "/farmer/dashboard")); });
self.addEventListener("message", (event) => { if (event.data?.type === "SKIP_WAITING") self.skipWaiting(); });
