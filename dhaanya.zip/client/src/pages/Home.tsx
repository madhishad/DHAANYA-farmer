import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { languageOptions, listenForCommand, speak, translate, type SupportedLanguage } from "@/lib/i18n";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import NotificationCenter from "@/components/NotificationCenter";
import {
  AlertCircle,
  ArrowRight,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  ClipboardCheck,
  CloudOff,
  CreditCard,
  Database,
  Download,
  FileCheck2,
  Gauge,
  HandCoins,
  IndianRupee,
  Languages,
  Leaf,
  LifeBuoy,
  ListChecks,
  MapPin,
  Menu,
  MessageCircle,
  Mic,
  MoreHorizontal,
  Network,
  PackageCheck,
  Phone,
  Plus,
  QrCode,
  ReceiptText,
  RefreshCw,
  Scale,
  ScanLine,
  Search,
  Settings2,
  ShieldCheck,
  Sprout,
  Tractor,
  Truck,
  UserRound,
  UsersRound,
  Volume2,
  WalletCards,
  WifiOff,
  X,
  Zap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

type Role = "farmer" | "officer" | "admin" | "assistant";
type NavId = string;

type NavItem = {
  id: NavId;
  label: string;
  icon: LucideIcon;
};

type QueueFarmer = {
  id: number;
  token: string;
  name: string;
  crop: string;
  qty: string;
  status: "Arrived" | "Waiting" | "Quality";
  time: string;
};

const roleMeta: Record<Role, { label: string; short: string; name: string; location: string; subtitle: string; color: string }> = {
  farmer: { label: "Farmer", short: "SD", name: "Sita Devi", location: "Bargaon · Sehore, MP", subtitle: "Welcome back, Sita", color: "#dcae57" },
  officer: { label: "Centre Officer", short: "RP", name: "Ramesh Patil", location: "Centre MP-04 · Sehore", subtitle: "Good morning, Ramesh", color: "#6b9ed6" },
  admin: { label: "Admin / Supervisor", short: "AK", name: "Anita Kulkarni", location: "Sehore District · MP", subtitle: "District operations", color: "#9a82cf" },
  assistant: { label: "Village Assistant", short: "MK", name: "Meena Kumari", location: "CSC Bargaon · Sehore", subtitle: "Assisted service desk", color: "#d27f61" },
};

const navItems: Record<Role, NavItem[]> = {
  farmer: [
    { id: "overview", label: "My dashboard", icon: Gauge },
    { id: "book", label: "Book a slot", icon: CalendarDays },
    { id: "queue", label: "My queue token", icon: ListChecks },
    { id: "records", label: "Procurement records", icon: ReceiptText },
    { id: "payments", label: "Payments", icon: WalletCards },
  ],
  officer: [
    { id: "overview", label: "Centre overview", icon: Gauge },
    { id: "queue", label: "Live queue", icon: ListChecks },
    { id: "weighment", label: "Weighment desk", icon: Scale },
    { id: "quality", label: "Quality checks", icon: ClipboardCheck },
    { id: "payments", label: "Payment release", icon: IndianRupee },
  ],
  admin: [
    { id: "overview", label: "District overview", icon: Gauge },
    { id: "centres", label: "Centre performance", icon: Network },
    { id: "transparency", label: "Transparency ledger", icon: ShieldCheck },
    { id: "reports", label: "Reports & exports", icon: Download },
    { id: "settings", label: "System settings", icon: Settings2 },
  ],
  assistant: [
    { id: "overview", label: "Assist desk", icon: Gauge },
    { id: "register", label: "Register a farmer", icon: UserRound },
    { id: "booking", label: "Book on behalf", icon: CalendarDays },
    { id: "lookup", label: "Find a farmer", icon: Search },
    { id: "sync", label: "Offline sync", icon: RefreshCw },
  ],
};

const stages = [
  { label: "Registration", icon: UserRound },
  { label: "Slot booked", icon: CalendarDays },
  { label: "Arrival", icon: Truck },
  { label: "Weighment", icon: Scale },
  { label: "Quality", icon: ClipboardCheck },
  { label: "Payment", icon: HandCoins },
];

const initialQueue: QueueFarmer[] = [
  { id: 1, token: "A-024", name: "Sita Devi", crop: "Soybean", qty: "18.5 qtl", status: "Arrived", time: "09:05" },
  { id: 2, token: "A-025", name: "Mohan Singh", crop: "Soybean", qty: "24 qtl", status: "Waiting", time: "09:12" },
  { id: 3, token: "A-026", name: "Kavita Bai", crop: "Wheat", qty: "16 qtl", status: "Waiting", time: "09:18" },
  { id: 4, token: "A-027", name: "Raju Yadav", crop: "Soybean", qty: "31 qtl", status: "Quality", time: "09:24" },
];

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`flex items-center ${compact ? "gap-2" : "gap-3"}`}>
      <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-[14px] bg-[#1e6b4b] text-white shadow-[0_7px_16px_rgba(30,107,75,.2)]">
        <Leaf className="h-5 w-5" strokeWidth={2.5} />
        <span className="absolute bottom-[7px] right-[7px] h-1.5 w-1.5 rounded-full bg-[#dcae57]" />
      </div>
      {!compact && (
        <div className="min-w-0">
          <div className="font-display text-[18px] font-extrabold tracking-[-0.03em] text-[#173c2b]">Dhaanya</div>
          <div className="whitespace-nowrap text-[10px] font-semibold uppercase tracking-[.14em] text-[#8a988f]">Harvest to payment</div>
        </div>
      )}
    </div>
  );
}

function StatusPill({ children, tone = "green", icon: Icon }: { children: React.ReactNode; tone?: "green" | "amber" | "blue" | "red" | "slate"; icon?: LucideIcon }) {
  const tones = {
    green: "bg-[#e7f4e9] text-[#267044]",
    amber: "bg-[#fff2d9] text-[#8f6418]",
    blue: "bg-[#e8f1fb] text-[#3b6f9f]",
    red: "bg-[#fbe8e5] text-[#9d4a40]",
    slate: "bg-[#eef1ee] text-[#67746c]",
  };
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold ${tones[tone]}`}>{Icon && <Icon className="h-3 w-3" />}{children}</span>;
}

function SectionHeading({ eyebrow, title, action, onAction }: { eyebrow?: string; title: string; action?: string; onAction?: () => void }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div>
        {eyebrow && <div className="mb-1 text-[10px] font-bold uppercase tracking-[.16em] text-[#8a988f]">{eyebrow}</div>}
        <h2 className="font-display text-[18px] font-extrabold tracking-[-.025em] text-[#193329]">{title}</h2>
      </div>
      {action && <button onClick={onAction} className="inline-flex items-center gap-1 text-xs font-bold text-[#2c8057] transition hover:text-[#164c34]">{action}<ChevronRight className="h-3.5 w-3.5" /></button>}
    </div>
  );
}

function MetricCard({ label, value, note, icon: Icon, tone = "green", compact = false }: { label: string; value: string; note: string; icon: LucideIcon; tone?: "green" | "amber" | "blue" | "violet"; compact?: boolean }) {
  const toneMap = {
    green: { bg: "bg-[#e9f5eb]", icon: "bg-[#d8efdc] text-[#277047]" },
    amber: { bg: "bg-[#fff3da]", icon: "bg-[#ffe8b1] text-[#8d641a]" },
    blue: { bg: "bg-[#eaf2fa]", icon: "bg-[#d9eafa] text-[#3a6f9e]" },
    violet: { bg: "bg-[#f0ecf8]", icon: "bg-[#e3daf3] text-[#7357a3]" },
  };
  const toneClasses = toneMap[tone];
  return (
    <div className={`group rounded-[18px] border border-[#e4eae3] p-4 shadow-[0_8px_24px_rgba(28,67,47,.035)] transition hover:-translate-y-0.5 hover:shadow-[0_12px_28px_rgba(28,67,47,.08)] ${toneClasses.bg}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="mb-2 text-[11px] font-semibold text-[#6b7a70]">{label}</div>
          <div className={`${compact ? "text-[22px]" : "text-[28px]"} font-display font-extrabold tracking-[-.05em] text-[#173c2b]`}>{value}</div>
        </div>
        <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${toneClasses.icon}`}><Icon className="h-[18px] w-[18px]" /></div>
      </div>
      <div className="mt-3 text-[11px] font-semibold text-[#678072]">{note}</div>
    </div>
  );
}

function ProgressStage({ stage, index, current }: { stage: { label: string; icon: LucideIcon }; index: number; current: number }) {
  const Icon = stage.icon;
  const done = index < current;
  const active = index === current;
  return (
    <div className="relative flex min-w-0 flex-1 flex-col items-center gap-2 text-center">
      {index < stages.length - 1 && <div className={`absolute left-[calc(50%+21px)] right-[calc(-50%+21px)] top-[15px] h-[2px] ${index < current ? "bg-[#4f9b70]" : "bg-[#d9e4d9]"}`} />}
      <div className={`relative z-10 flex h-8 w-8 items-center justify-center rounded-full border-2 ${done ? "border-[#4f9b70] bg-[#4f9b70] text-white" : active ? "border-[#4f9b70] bg-white text-[#2e8056] shadow-[0_0_0_4px_rgba(79,155,112,.12)]" : "border-[#dce5dc] bg-white text-[#a0ada4]"}`}>
        {done ? <Check className="h-4 w-4" strokeWidth={3} /> : <Icon className="h-3.5 w-3.5" />}
      </div>
      <div className={`text-[9px] font-bold leading-tight sm:text-[10px] ${active || done ? "text-[#346e4e]" : "text-[#89978e]"}`}>{stage.label}</div>
    </div>
  );
}

function OfflineBanner({ onLearn }: { onLearn: () => void }) {
  const { t } = useLanguage();
  return (
    <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#dce8da] bg-[#f0f7ef] px-4 py-3 text-[#456a50]">
      <div className="flex items-center gap-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-[#4e8d64] shadow-sm"><WifiOff className="h-4 w-4" /></div>
        <div><div className="text-xs font-extrabold">{t("farmer.worksWeak")}</div><div className="mt-0.5 text-[11px] text-[#678072]">{t("farmer.savedSync")}</div></div>
      </div>
      <button onClick={onLearn} className="inline-flex items-center gap-1 text-[11px] font-extrabold text-[#2c8057]">{t("farmer.howWorks")} <ArrowRight className="h-3.5 w-3.5" /></button>
    </div>
  );
}

function FarmerOverview({ onAction, onNav }: { onAction: (message: string) => void; onNav: (id: string) => void }) {
  const { t } = useLanguage();
  const translatedStages = stages.map((stage, index) => ({ ...stage, label: [t("auth.register"), t("booking.confirmed"), t("queue.centreStatus"), t("weighment.net"), t("quality.accepted"), t("payment.paid")][index] }));
  return (
    <>
      <div className="mb-6 overflow-hidden rounded-[22px] bg-[#1e6b4b] p-5 text-white shadow-[0_18px_35px_rgba(30,107,75,.16)] sm:p-6">
        <div className="relative z-10 flex flex-col justify-between gap-6 sm:flex-row sm:items-center">
          <div className="max-w-[520px]">
            <div className="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[.14em] text-[#aed5b7]"><Sprout className="h-3.5 w-3.5" /> {t("farmer.soybeanProcurement")}</div>
            <h2 className="font-display text-[26px] font-extrabold leading-[1.08] tracking-[-.04em] sm:text-[31px]">{t("brand.fromHarvest")}</h2>
            <p className="mt-3 max-w-[390px] text-sm leading-relaxed text-[#d7ebd8]">{t("brand.tagline")}</p>
          </div>
          <div className="flex shrink-0 items-center gap-3 self-start sm:self-auto">
            <button onClick={() => onNav("book")} className="inline-flex items-center gap-2 rounded-xl bg-[#f3d38d] px-4 py-3 text-xs font-extrabold text-[#3d2e16] shadow-lg transition hover:bg-[#f8dfa5] active:scale-[.98]"><CalendarDays className="h-4 w-4" /> {t("nav.book")}</button>
            <button onClick={() => onAction("Voice help is ready. Try saying: book a slot.")} aria-label="Voice help" className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/20 bg-white/10 text-white transition hover:bg-white/20"><Volume2 className="h-4 w-4" /></button>
          </div>
        </div>
        <div className="pointer-events-none absolute hidden h-56 w-56 translate-x-[44rem] -translate-y-12 rounded-full border-[30px] border-white/5 sm:block" />
      </div>

      <SectionHeading eyebrow={t("farmer.journey")} title={t("farmer.journey")} action={t("common.continue")} onAction={() => onAction(t("common.continue"))} />
      <div className="mb-7 rounded-[18px] border border-[#e3ebe1] bg-white px-3 py-5 shadow-[0_8px_24px_rgba(28,67,47,.035)] sm:px-6">
        <div className="flex w-full items-start gap-1 sm:gap-2">{translatedStages.map((stage, index) => <ProgressStage key={stage.label} stage={stage} index={index} current={1} />)}</div>
      </div>

      <div className="mb-7 grid gap-4 sm:grid-cols-3">
        <MetricCard label={t("farmer.currentToken")} value="A-024" note={t("farmer.arrivalNote")} icon={ListChecks} tone="amber" />
        <MetricCard label={t("farmer.expectedQuantity")} value="18.5 qtl" note={t("farmer.lotNote")} icon={Scale} tone="green" />
        <MetricCard label={t("farmer.lastPayment")} value="₹42,680" note={t("farmer.creditedDate")} icon={IndianRupee} tone="blue" />
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.18fr_.82fr]">
        <div>
          <SectionHeading eyebrow={t("farmer.welcome")} title={t("common.help")} />
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              { label: t("booking.title"), sub: t("booking.chooseDate"), icon: CalendarDays, tone: "green", action: () => onNav("book") },
              { label: t("farmer.currentToken"), sub: t("queue.yourToken"), icon: QrCode, tone: "amber", action: () => onNav("queue") },
              { label: t("nav.records"), sub: `${t("weighment.net")}, ${t("quality.accepted")} & ${t("nav.payments")}`, icon: FileCheck2, tone: "blue", action: () => onNav("records") },
              { label: t("common.help"), sub: t("assistant.assisted"), icon: MessageCircle, tone: "violet", action: () => onAction(t("assistant.assisted")) },
            ].map((item) => {
              const Icon = item.icon;
              const color = item.tone === "green" ? "bg-[#eaf6eb] text-[#31784f]" : item.tone === "amber" ? "bg-[#fff3db] text-[#94691b]" : item.tone === "blue" ? "bg-[#eaf2fa] text-[#3e78a6]" : "bg-[#f1ecf8] text-[#735ba2]";
              return <button key={item.label} onClick={item.action} className="group flex items-center gap-3 rounded-[16px] border border-[#e3ebe1] bg-white p-4 text-left shadow-[0_7px_22px_rgba(28,67,47,.03)] transition hover:-translate-y-0.5 hover:border-[#c7dbc8] hover:shadow-[0_12px_26px_rgba(28,67,47,.08)]"><span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${color}`}><Icon className="h-[18px] w-[18px]" /></span><span className="min-w-0"><span className="block text-sm font-extrabold text-[#263d30]">{item.label}</span><span className="mt-1 block text-[11px] font-medium text-[#829087]">{item.sub}</span></span><ChevronRight className="ml-auto h-4 w-4 shrink-0 text-[#b5c0b7] transition group-hover:translate-x-0.5 group-hover:text-[#4a8961]" /></button>;
            })}
          </div>
        </div>
        <div>
          <SectionHeading eyebrow={t("farmer.notifications")} title={t("farmer.notifications")} action={t("common.continue")} onAction={() => onAction(t("offline.online"))} />
          <div className="divide-y divide-[#edf0ec] rounded-[18px] border border-[#e3ebe1] bg-white px-4 shadow-[0_7px_22px_rgba(28,67,47,.03)]">
            {[
              { icon: CheckCircle2, title: t("farmer.slotConfirmed"), body: t("farmer.slotConfirmedBody"), time: "Today, 08:42", tone: "green" },
              { icon: IndianRupee, title: t("farmer.paymentCredited"), body: t("farmer.paymentCreditedBody"), time: "18 Aug, 17:36", tone: "blue" },
              { icon: LifeBuoy, title: t("farmer.mspUpdated"), body: t("farmer.mspUpdatedBody"), time: "15 Aug, 10:15", tone: "amber" },
            ].map((item) => { const Icon = item.icon; return <div key={item.title} className="flex gap-3 py-4"><span className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${item.tone === "green" ? "bg-[#eaf6eb] text-[#3b8456]" : item.tone === "blue" ? "bg-[#eaf2fa] text-[#3e78a6]" : "bg-[#fff3db] text-[#94691b]"}`}><Icon className="h-4 w-4" /></span><div className="min-w-0"><div className="text-xs font-extrabold text-[#2a4033]">{item.title}</div><div className="mt-1 text-[11px] leading-relaxed text-[#7c8a80]">{item.body}</div><div className="mt-1.5 text-[10px] font-bold text-[#a2aea5]">{item.time}</div></div></div>; })}
          </div>
        </div>
      </div>
    </>
  );
}

function FarmerSection({ activeNav, onAction, onNav }: { activeNav: string; onAction: (message: string) => void; onNav: (id: string) => void }) {
  if (activeNav === "overview") return <FarmerOverview onAction={onAction} onNav={onNav} />;
  if (activeNav === "book") return <BookingPanel onAction={onAction} />;
  if (activeNav === "queue") return <QueueTokenPanel onAction={onAction} />;
  if (activeNav === "records") return <RecordsPanel onAction={onAction} />;
  return <PaymentsPanel onAction={onAction} />;
}

function BookingPanel({ onAction }: { onAction: (message: string) => void }) {
  const { t } = useLanguage();
  const farmerKey = useMemo(() => {
    try { return JSON.parse(localStorage.getItem("dhaanya-demo-session") || "{}").email || "farmer@dhaanya.demo"; } catch { return "farmer@dhaanya.demo"; }
  }, []);
  const [selectedDate, setSelectedDate] = useState("24 Sep");
  const [selectedSlot, setSelectedSlot] = useState("09:30 AM");
  const [selectedCentre, setSelectedCentre] = useState("BARGAON-PC-001");
  const centresQuery = trpc.booking.centres.useQuery({ farmerKey });
  const currentQuery = trpc.booking.current.useQuery({ farmerKey });
  const utils = trpc.useUtils();
  const bookSlot = trpc.booking.create.useMutation({
    onSuccess: (booking) => { void utils.booking.current.invalidate({ farmerKey }); onAction(`${t("booking.confirmSlot")} · ${booking.token}`); toast.success(`${booking.centreName} · ${booking.token}`); },
    onError: (error) => toast.error(error.message),
  });
  const centres = centresQuery.data ?? [];
  const currentBooking = currentQuery.data;
  return <div className="animate-rise-in"><SectionHeading eyebrow={t("booking.journeyEyebrow")} title={t("booking.titleShort")} action={t("booking.needHelp")} onAction={() => onAction(t("booking.assistantHelp"))} /><div className="grid gap-5 lg:grid-cols-[1fr_360px]"><div className="rounded-[20px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)] sm:p-6"><div className="mb-6 flex items-center gap-3 rounded-xl bg-[#f3f8f1] p-3 text-[#477254]"><Zap className="h-4 w-4" /><span className="text-xs font-bold">{t("booking.quieter")}</span></div><label className="mb-2 block text-xs font-extrabold text-[#365042]">{t("booking.chooseCentreNumber")}</label><div className="grid gap-3 sm:grid-cols-2">{centres.map((centre) => <button key={centre.id} onClick={() => setSelectedCentre(centre.id)} className={`rounded-xl border p-3 text-left transition ${selectedCentre === centre.id ? "border-[#4b986b] bg-[#f1f8f0] ring-2 ring-[#dceede]" : "border-[#e2e9e1] hover:border-[#b8d1bd]"}`}><div className="flex items-start gap-2"><MapPin className={`mt-0.5 h-4 w-4 ${selectedCentre === centre.id ? "text-[#318053]" : "text-[#9aa9a0]"}`} /><span><span className="block text-xs font-extrabold text-[#294334]">{centre.name}</span><span className="mt-1 block text-[10px] font-semibold text-[#87938b]">{centre.distanceKm} km · {centre.estimatedWaitMinutes} min wait · {centre.availableSlots} {t("booking.spotsLeft")}</span></span></div></button>)}</div><label className="mb-2 mt-6 block text-xs font-extrabold text-[#365042]">{t("booking.chooseDateNumber")}</label><div className="grid grid-cols-3 gap-2 sm:grid-cols-5">{["24 Sep", "25 Sep", "26 Sep", "27 Sep", "28 Sep"].map((date, index) => <button key={date} onClick={() => setSelectedDate(date)} className={`rounded-xl border px-2 py-3 text-center transition ${selectedDate === date ? "border-[#4b986b] bg-[#1e6b4b] text-white" : "border-[#e2e9e1] bg-white text-[#42614d] hover:border-[#b8d1bd]"}`}><span className="block text-[10px] font-bold opacity-75">{["Wed", "Thu", "Fri", "Sat", "Sun"][index]}</span><span className="mt-1 block text-sm font-extrabold">{date.split(" ")[0]}</span></button>)}</div><label className="mb-2 mt-6 block text-xs font-extrabold text-[#365042]">{t("booking.chooseTimeNumber")}</label><div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{["08:30 AM", "09:30 AM", "10:30 AM", "11:30 AM"].map((slot, index) => <button key={slot} onClick={() => setSelectedSlot(slot)} className={`rounded-xl border px-3 py-3 text-xs font-bold transition ${selectedSlot === slot ? "border-[#e2bf70] bg-[#fff4dd] text-[#7f5c1e]" : "border-[#e2e9e1] text-[#55705e] hover:border-[#d9c18b]"}`}><span className="block">{slot}</span><span className="mt-1 block text-[10px] font-medium opacity-70">{index === 1 ? "Recommended" : `${12 + index * 3} ${t("booking.spotsLeft")}`}</span></button>)}</div><button disabled={bookSlot.isPending || !selectedCentre} onClick={() => bookSlot.mutate({ farmerKey, centreId: selectedCentre, crop: "SOYBEAN", date: selectedDate, startTime: selectedSlot })} className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-[#1e6b4b] px-4 py-3.5 text-sm font-extrabold text-white shadow-[0_8px_18px_rgba(30,107,75,.18)] transition hover:bg-[#16583c] active:scale-[.99]">{t("booking.confirmSlot")} <ArrowRight className="h-4 w-4" /></button></div><div className="rounded-[20px] border border-[#e3ebe1] bg-[#f0f7ef] p-5"><div className="mb-4 flex items-center gap-2 text-[#356c4a]"><CalendarDays className="h-4 w-4" /><span className="text-xs font-extrabold">{t("booking.yourSelection")}</span></div><div className="space-y-4 text-xs"><div><div className="text-[10px] font-bold uppercase tracking-widest text-[#82978a]">{t("booking.centre")}</div><div className="mt-1 font-extrabold text-[#294334]">{centres.find((centre) => centre.id === selectedCentre)?.name ?? currentBooking?.centreName ?? selectedCentre}</div></div><div><div className="text-[10px] font-bold uppercase tracking-widest text-[#82978a]">{t("booking.dateTime")}</div><div className="mt-1 font-extrabold text-[#294334]">{selectedDate} · {selectedSlot}</div></div><div><div className="text-[10px] font-bold uppercase tracking-widest text-[#82978a]">{t("booking.expectedWait")}</div><div className="mt-1 font-extrabold text-[#2e8056]">{centres.find((centre) => centre.id === selectedCentre)?.estimatedWaitMinutes ?? currentBooking?.estimatedWaitMinutes ?? 18} minutes</div></div></div><div className="mt-7 rounded-xl bg-white/70 p-3 text-[11px] leading-relaxed text-[#678072]"><ShieldCheck className="mb-2 h-4 w-4 text-[#4e8f61]" /> {t("booking.reschedule")}</div></div></div></div>;
}

function QueueTokenPanel({ onAction }: { onAction: (message: string) => void }) {
  const { t } = useLanguage();
  const [, navigate] = useLocation();
  return <div className="animate-rise-in"><SectionHeading eyebrow="Your place in line" title="Queue token A-024" action="Get directions" onAction={() => navigate("/farmer/centre")} /><div className="grid gap-5 lg:grid-cols-[.85fr_1.15fr]"><div className="rounded-[22px] bg-[#1e6b4b] p-6 text-white shadow-[0_18px_35px_rgba(30,107,75,.16)]"><div className="flex items-start justify-between"><div><div className="text-[10px] font-bold uppercase tracking-[.16em] text-[#b8ddbd]">{t("farmer.today")}</div><div className="mt-4 text-[64px] font-display font-extrabold leading-none tracking-[-.08em] text-[#f7d991]">A-024</div><div className="mt-2 text-sm font-bold text-[#d7ebd8]">{t("farmer.youFirst")}</div></div><div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white p-2"><QrCode className="h-full w-full text-[#214e37]" /></div></div><div className="mt-8 grid grid-cols-2 gap-3"><div className="rounded-xl bg-white/10 p-3"><div className="text-[10px] font-bold text-[#b8ddbd]">{t("farmer.arrivalSlot")}</div><div className="mt-1 text-sm font-extrabold">09:30 AM</div></div><div className="rounded-xl bg-white/10 p-3"><div className="text-[10px] font-bold text-[#b8ddbd]">{t("farmer.estWaitShort")}</div><div className="mt-1 text-sm font-extrabold">18 min</div></div></div><button onClick={() => onAction("Token saved to this device. You can show it offline at the centre.")} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-white/12 py-3 text-xs font-extrabold text-white ring-1 ring-white/20 transition hover:bg-white/20"><Download className="h-3.5 w-3.5" />{t("farmer.saveToken")} </button></div><div className="rounded-[22px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)]"><div className="mb-5 flex items-center justify-between"><div><div className="text-[10px] font-bold uppercase tracking-[.16em] text-[#8a988f]">{t("farmer.liveAt")}</div><div className="mt-1 font-display text-[21px] font-extrabold tracking-[-.03em] text-[#233d2f]">{t("farmer.centreQueue")}</div></div><StatusPill tone="green" icon={CheckCircle2}>{t("farmer.liveNow")}</StatusPill></div>{["A-023", "A-024", "A-025", "A-026"].map((token, index) => <div key={token} className={`flex items-center gap-3 border-t border-[#eef1ed] py-3 ${token === "A-024" ? "-mx-2 rounded-xl bg-[#f1f8f0] px-2" : ""}`}><span className={`flex h-7 w-7 items-center justify-center rounded-lg text-[10px] font-extrabold ${token === "A-024" ? "bg-[#4e976c] text-white" : "bg-[#edf3ed] text-[#62806a]"}`}>{index + 1}</span><span className="text-xs font-extrabold text-[#2d4736]">{token}{token === "A-024" && <span className="ml-2 text-[10px] font-semibold text-[#4e976c]">{t("farmer.you")}</span>}</span><span className="ml-auto text-[11px] font-semibold text-[#91a098]">{index === 0 ? t("farmer.atWeighment") : index === 1 ? t("farmer.yourTurn") : `${(index - 1) * 9 + 18} ${t("farmer.estWaitShort")}`}</span></div>)}<div className="mt-5 flex items-start gap-2 rounded-xl bg-[#fff6e4] p-3 text-[11px] leading-relaxed text-[#7d642e]"><AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {t("farmer.arriveNote")}</div></div></div></div>;
}

function RecordsPanel({ onAction }: { onAction: (message: string) => void }) {
  const { t } = useLanguage();
  const { data: paymentData } = trpc.payments.history.useQuery({ farmerKey: "demo-farmer" });
  const rows = [{ lot: "LOT-0261", date: "18 Aug 2026", weight: "18.5 qtl", quality: "FAQ", amount: "₹42,680" }, { lot: "LOT-0208", date: "04 Aug 2026", weight: "12 qtl", quality: "FAQ", amount: "₹29,040" }, { lot: "LOT-0142", date: "26 Jul 2026", weight: "12 qtl", quality: "FAQ", amount: "₹40,320" }];
  const openReceipt = (lot: string) => {
    const payment = paymentData?.records.find((record) => record.lot === lot);
    if (!payment) { toast.error(t("payment.receiptUnavailable")); return; }
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>${payment.lot} · Dhaanya</title><style>body{font-family:system-ui,sans-serif;background:#f8f6ef;color:#193329;padding:40px;max-width:720px;margin:auto}.receipt{background:#fff;border:1px solid #e3ebe1;border-radius:18px;padding:32px;box-shadow:0 8px 24px rgba(28,67,47,.08)}h1{margin:0 0 8px;color:#1e6b4b}h2{margin-top:32px;border-bottom:1px solid #edf1ec;padding-bottom:12px}dl{display:grid;grid-template-columns:1fr 1fr;gap:16px}dt{font-size:12px;color:#718177}dd{margin:4px 0 0;font-weight:700}footer{margin-top:32px;color:#718177;font-size:12px}</style></head><body><main class="receipt"><h1>Dhaanya</h1><div>Procurement payment receipt</div><h2>${payment.lot}</h2><dl><div><dt>Payment date</dt><dd>${payment.date}</dd></div><div><dt>Crop</dt><dd>${payment.crop}</dd></div><div><dt>Quantity</dt><dd>${payment.quantityQuintals} qtl</dd></div><div><dt>Amount</dt><dd>₹${payment.amount.toLocaleString("en-IN")}</dd></div><div><dt>Status</dt><dd>${payment.status}</dd></div><div><dt>Transaction reference</dt><dd>${payment.transactionReference}</dd></div></dl><footer>Generated from the Dhaanya payment record.</footer></main></body></html>`;
    const url = URL.createObjectURL(new Blob([html], { type: "text/html;charset=utf-8" }));
    const receiptWindow = window.open(url, "_blank", "noopener,noreferrer");
    if (!receiptWindow) { URL.revokeObjectURL(url); toast.error(t("payment.receiptBlocked")); return; }
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
    toast.success(t("payment.receiptOpened"));
  };
  return <div className="animate-rise-in"><SectionHeading eyebrow="Complete transparency" title="Procurement records" action="Download all" onAction={() => onAction("Your records are being prepared for download.")} /><div className="mb-5 grid gap-4 sm:grid-cols-3"><MetricCard label="Total procured" value="42.5 qtl" note="Across 3 lots this season" icon={Scale} tone="green" compact /><MetricCard label="Avg. quality" value="FAQ" note="Fair Average Quality" icon={ShieldCheck} tone="blue" compact /><MetricCard label="Total received" value="₹1.12L" note="100% paid to account" icon={IndianRupee} tone="amber" compact /></div><div className="overflow-hidden rounded-[20px] border border-[#e3ebe1] bg-white shadow-[0_8px_24px_rgba(28,67,47,.035)]"><div className="grid grid-cols-[1.1fr_.8fr_.8fr_.8fr_auto] gap-3 border-b border-[#edf1ec] bg-[#f8faf7] px-5 py-3 text-[10px] font-extrabold uppercase tracking-wider text-[#839189]"><span>Lot / date</span><span>Weight</span><span>Quality</span><span>Amount</span><span /></div>{rows.map((row) => <div key={row.lot} className="grid grid-cols-[1.1fr_.8fr_.8fr_.8fr_auto] items-center gap-3 border-b border-[#f0f3ef] px-5 py-4 last:border-0"><div><div className="text-xs font-extrabold text-[#2c4535]">{row.lot}</div><div className="mt-1 text-[10px] font-semibold text-[#9aa69d]">{row.date}</div></div><span className="text-xs font-bold text-[#4f6856]">{row.weight}</span><StatusPill tone="green">{row.quality}</StatusPill><span className="text-xs font-extrabold text-[#2c4535]">{row.amount}</span><button onClick={() => openReceipt(row.lot)} aria-label={`Open ${row.lot} receipt`} className="text-[#9aaa9f] transition hover:text-[#2b8057]"><MoreHorizontal className="h-4 w-4" /></button></div>)}</div></div>;
}

function PaymentsPanel({ onAction }: { onAction: (message: string) => void }) {
  const { t, language } = useLanguage();
  const formatDate = (value: string) => new Intl.DateTimeFormat(language === "ta" ? "ta-IN" : language === "hi" ? "hi-IN" : language === "pa" ? "pa-IN" : "en-IN", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(value));
  const { data: paymentData } = trpc.payments.history.useQuery({ farmerKey: "demo-farmer" });
  const payments = paymentData?.records ?? [];
  const cropName = (crop: string) => crop === "SOYBEAN" ? (language === "ta" ? "சோயாபீன்" : language === "hi" ? "सोयाबीन" : language === "pa" ? "ਸੋਇਆਬੀਨ" : "Soybean") : crop === "WHEAT" ? (language === "ta" ? "கோதுமை" : language === "hi" ? "गेहूं" : language === "pa" ? "ਕਣਕ" : "Wheat") : crop;
  return <div className="animate-rise-in"><SectionHeading eyebrow={t("payment.paymentHistory")} title={t("payment.paymentHistory")} action={t("payment.details")} onAction={() => onAction(t("payment.details"))} /><div className="mb-5 rounded-[20px] bg-[#1e6b4b] p-6 text-white shadow-[0_18px_35px_rgba(30,107,75,.16)]"><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.16em] text-[#b8ddbd]"><IndianRupee className="h-3.5 w-3.5" /> {t("payment.receivedSeason")}</div><div className="mt-3 text-[35px] font-display font-extrabold tracking-[-.05em]">₹{(paymentData?.totalReceived ?? 0).toLocaleString("en-IN")}</div><div className="mt-2 text-xs font-semibold text-[#d7ebd8]">{t("payment.creditedMessage")} · {t("payment.lastUpdatedToday")}</div><button onClick={() => onAction(t("payment.download"))} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-white/12 px-3 py-2.5 text-xs font-extrabold ring-1 ring-white/20 transition hover:bg-white/20"><Download className="h-3.5 w-3.5" /> {t("payment.download")}</button></div><div className="rounded-[20px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)]"><div className="mb-2 text-[10px] font-bold uppercase tracking-widest text-[#8a988f]">{t("payment.recentCredits")}</div>{payments.map((payment) => <div key={payment.lot} className="flex flex-wrap items-center gap-3 border-b border-[#eef1ed] py-4 last:border-0"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#e8f3e9] text-[#337b50]"><CreditCard className="h-4 w-4" /></span><div className="min-w-[180px] flex-1"><div className="text-xs font-extrabold text-[#2d4535]">{payment.amount.toLocaleString("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 })}</div><div className="mt-1 text-[10px] font-semibold text-[#9aa69d]">{payment.lot} · {cropName(payment.crop)} · {payment.quantityQuintals} qtl</div><div className="mt-1 text-[10px] font-semibold text-[#9aa69d]">{t("payment.date")}: {formatDate(payment.date)} · {t("payment.transactionReference")}: {payment.transactionReference}</div></div><StatusPill tone="green" icon={CheckCircle2}>{t(`payment.status${payment.status === "PAID" ? "Credited" : payment.status === "PAYMENT_PENDING" ? "Pending" : "Failed"}`)}</StatusPill></div>)}</div></div>;
}

function OfficerOverview({ queue, checkedIn, onCheckIn, onAction }: { queue: QueueFarmer[]; checkedIn: number[]; onCheckIn: (id: number) => void; onAction: (message: string) => void }) {
  const { data: centreData } = trpc.centre.dashboard.useQuery();
  const arrived = queue.filter((item) => item.status === "Arrived").length;
  return <><div className="mb-6 flex flex-col justify-between gap-4 rounded-[20px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)] sm:flex-row sm:items-center sm:p-6"><div><div className="mb-1 flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest text-[#6c8c77]"><span className="pulse-dot h-2 w-2 rounded-full bg-[#4b9a6b]" /> Centre is open · 08:00 AM – 05:00 PM</div><h2 className="font-display text-[25px] font-extrabold tracking-[-.04em] text-[#193329]">Good morning, Ramesh.</h2><p className="mt-1 text-xs font-medium text-[#809087]">You have {queue.length} farmers in today’s processing queue.</p></div><button onClick={() => onAction("Centre status is visible to district supervisors.")} className="inline-flex items-center gap-2 self-start rounded-xl border border-[#dfe9de] px-3 py-2.5 text-xs font-extrabold text-[#3c6c4b] transition hover:border-[#b6d0b9] sm:self-auto"><ShieldCheck className="h-4 w-4" /> Transparent mode on</button></div><div className="mb-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><MetricCard label="Today’s farmers" value={String(centreData?.todayFarmers ?? queue.length)} note="Live from centre procurement data" icon={UsersRound} tone="green" /><MetricCard label="In live queue" value={String(centreData?.waitingFarmers ?? 0)} note={`Avg. wait ${centreData?.averageWaitingMinutes ?? 0} minutes`} icon={ListChecks} tone="amber" /><MetricCard label="Weighed today" value={String(centreData?.pendingWeighments ?? 0)} note={`${centreData?.totalQuintals ?? 0} quintals total`} icon={Scale} tone="blue" /><MetricCard label="Pending payments" value={String(centreData?.pendingPayments ?? 0)} note="Lots awaiting release" icon={IndianRupee} tone="violet" /></div><div className="grid gap-5 xl:grid-cols-[1.15fr_.85fr]"><div><SectionHeading eyebrow="Action needed" title="Today’s live queue" action="Open full queue" onAction={() => onAction("Full queue view opened.")} /><div className="overflow-hidden rounded-[20px] border border-[#e3ebe1] bg-white shadow-[0_8px_24px_rgba(28,67,47,.035)]"><div className="hidden grid-cols-[.8fr_1.2fr_1fr_.8fr_.8fr_auto] gap-3 border-b border-[#edf1ec] bg-[#f8faf7] px-4 py-3 text-[10px] font-extrabold uppercase tracking-wider text-[#839189] md:grid"><span>Token</span><span>Farmer</span><span>Crop</span><span>Quantity</span><span>Status</span><span /></div>{queue.map((item) => <div key={item.id} className="grid gap-2 border-b border-[#f0f3ef] px-4 py-4 last:border-0 md:grid-cols-[.8fr_1.2fr_1fr_.8fr_.8fr_auto] md:items-center md:gap-3"><div className="flex items-center justify-between md:block"><span className="text-xs font-extrabold text-[#2c4937]">{item.token}</span><span className="text-[10px] font-semibold text-[#a0aca3] md:hidden">{item.time}</span></div><div className="flex items-center gap-2"><span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#edf4ec] text-[10px] font-extrabold text-[#4c7b58]">{item.name.split(" ").map((s) => s[0]).join("")}</span><span className="text-xs font-bold text-[#3b5544]">{item.name}</span></div><span className="text-[11px] font-semibold text-[#75857a]">{item.crop}</span><span className="text-xs font-extrabold text-[#4d6655]">{item.qty}</span><span>{item.status === "Arrived" ? <StatusPill tone="green">Arrived</StatusPill> : item.status === "Quality" ? <StatusPill tone="blue">Quality</StatusPill> : <StatusPill tone="amber">Waiting</StatusPill>}</span><button disabled={item.status !== "Arrived" || checkedIn.includes(item.id)} onClick={() => onCheckIn(item.id)} className={`w-fit rounded-lg px-2.5 py-2 text-[10px] font-extrabold transition ${checkedIn.includes(item.id) ? "bg-[#e9f5eb] text-[#368151]" : item.status === "Arrived" ? "bg-[#1e6b4b] text-white hover:bg-[#15583b]" : "bg-[#f0f3ef] text-[#9aa79e]"}`}>{checkedIn.includes(item.id) ? "Checked in" : "Check in"}</button></div>)}</div></div><div><SectionHeading eyebrow="Centre pulse" title="Processing today" /><div className="rounded-[20px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)]"><div className="space-y-5">{[{ label: "Arrival & check-in", value: 68, count: `${centreData?.todayBookings ?? 0} farmers`, color: "bg-[#4e976c]" }, { label: "Weighment completed", value: 57, count: `${centreData?.pendingWeighments ?? 0} lots`, color: "bg-[#d9a84f]" }, { label: "Quality assessed", value: 43, count: `${centreData?.pendingQualityAssessments ?? 0} lots`, color: "bg-[#6e9dca]" }, { label: "Payment released", value: 26, count: `${centreData?.completedProcurement ?? 0} lots`, color: "bg-[#9278c5]" }].map((item) => <div key={item.label}><div className="mb-2 flex items-center justify-between text-xs"><span className="font-bold text-[#486354]">{item.label}</span><span className="font-extrabold text-[#2d4637]">{item.count}</span></div><div className="h-2 overflow-hidden rounded-full bg-[#edf2ec]"><div className={`h-full rounded-full ${item.color}`} style={{ width: `${item.value}%` }} /></div></div>)}</div><div className="mt-6 flex items-start gap-2 rounded-xl bg-[#f0f7ef] p-3 text-[11px] leading-relaxed text-[#5e7865]"><CloudOff className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#57906b]" /> Offline-ready. Last synced 2 minutes ago.</div></div></div></div></>;
}

function OfficerSection({ activeNav, queue, checkedIn, onCheckIn, onAction }: { activeNav: string; queue: QueueFarmer[]; checkedIn: number[]; onCheckIn: (id: number) => void; onAction: (message: string) => void }) {
  if (activeNav === "overview") return <OfficerOverview queue={queue} checkedIn={checkedIn} onCheckIn={onCheckIn} onAction={onAction} />;
  if (activeNav === "queue") return <QueueManagement queue={queue} checkedIn={checkedIn} onCheckIn={onCheckIn} onAction={onAction} />;
  return <InteractiveWorkDesk title={activeNav === "weighment" ? "Weighment desk" : activeNav === "quality" ? "Quality checks" : "Payment release"} onAction={onAction} />;
}

function QueueManagement({ queue, checkedIn, onCheckIn, onAction }: { queue: QueueFarmer[]; checkedIn: number[]; onCheckIn: (id: number) => void; onAction: (message: string) => void }) {
  return <div className="animate-rise-in"><SectionHeading eyebrow="Centre MP-04" title="Live queue management" action="Print queue" onAction={() => onAction("Queue slip sent to the centre printer.")} /><div className="mb-5 grid gap-4 sm:grid-cols-3"><MetricCard label="Waiting now" value="18" note="Across 3 arrival slots" icon={ListChecks} tone="amber" compact /><MetricCard label="Next token" value="A-024" note="Ready at the gate" icon={QrCode} tone="green" compact /><MetricCard label="Avg. processing" value="11 min" note="2 min faster today" icon={Zap} tone="blue" compact /></div><div className="rounded-[20px] border border-[#e3ebe1] bg-white p-4 shadow-[0_8px_24px_rgba(28,67,47,.035)] sm:p-5"><div className="mb-3 flex items-center justify-between"><div className="text-xs font-extrabold text-[#294334]">All farmers · Today, 24 Sep</div><div className="flex gap-2"><button onClick={() => onAction("Queue filters opened.")} className="rounded-lg border border-[#e0e8df] px-3 py-2 text-[10px] font-extrabold text-[#54705d]">Filter</button><button onClick={() => onAction("Queue synced successfully.")} className="rounded-lg bg-[#eff7ef] px-3 py-2 text-[10px] font-extrabold text-[#3f8155]"><RefreshCw className="mr-1 inline h-3 w-3" /> Sync</button></div></div>{queue.concat([{ id: 5, token: "A-028", name: "Shankar Lal", crop: "Soybean", qty: "20 qtl", status: "Waiting", time: "09:31" }]).map((item) => <div key={item.id} className="flex flex-wrap items-center gap-3 border-t border-[#eef1ed] py-4"><span className="min-w-[48px] text-xs font-extrabold text-[#2c4937]">{item.token}</span><div className="flex min-w-[150px] items-center gap-2"><span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#edf4ec] text-[10px] font-extrabold text-[#4c7b58]">{item.name.split(" ").map((s) => s[0]).join("")}</span><span className="text-xs font-bold text-[#3b5544]">{item.name}</span></div><span className="text-[11px] font-semibold text-[#75857a]">{item.crop} · {item.qty}</span><span className="ml-auto">{item.status === "Arrived" ? <StatusPill tone="green">Arrived</StatusPill> : item.status === "Quality" ? <StatusPill tone="blue">Quality</StatusPill> : <StatusPill tone="amber">Waiting</StatusPill>}</span><button disabled={item.status !== "Arrived" || checkedIn.includes(item.id)} onClick={() => onCheckIn(item.id)} className={`rounded-lg px-2.5 py-2 text-[10px] font-extrabold ${checkedIn.includes(item.id) ? "bg-[#e9f5eb] text-[#368151]" : item.status === "Arrived" ? "bg-[#1e6b4b] text-white" : "bg-[#f0f3ef] text-[#9aa79e]"}`}>{checkedIn.includes(item.id) ? "Checked in" : "Check in"}</button></div>)}</div></div>;
}

function InteractiveWorkDesk({ title, onAction }: { title: string; onAction: (message: string) => void }) {
  const [grossKg, setGrossKg] = useState("1250");
  const [tareKg, setTareKg] = useState("50");
  const [moisture, setMoisture] = useState("12");
  const [completed, setCompleted] = useState(false);
  const netKg = Math.max(0, Number(grossKg || 0) - Number(tareKg || 0));
  const quintals = netKg / 100;
  const deduction = Number(moisture || 0) > 14 ? quintals * 0.02 * 5328 : 0;
  const grossAmount = quintals * 5328;
  const finalAmount = grossAmount - deduction;
  const isWeighment = title === "Weighment desk";
  const isQuality = title === "Quality checks";
  return <div className="animate-rise-in"><SectionHeading eyebrow="Centre workflow" title={title} action="View audit trail" onAction={() => onAction("Audit trail opened for this desk.")} /><div className="grid gap-5 lg:grid-cols-[1fr_340px]"><div className="rounded-[20px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)]"><div className="mb-5 flex items-start justify-between"><div><div className="text-xs font-extrabold text-[#294334]">{isWeighment ? "Enter manual weighment" : isQuality ? "Assess lot quality" : "Review payment calculation"}</div><div className="mt-1 text-[11px] font-medium text-[#87958b]">Booking B-024 · Sita Devi · Soybean</div></div><StatusPill tone={completed ? "green" : "amber"} icon={completed ? CheckCircle2 : AlertCircle}>{completed ? "Completed" : "Pending action"}</StatusPill></div>{isWeighment && <div className="space-y-4"><div className="rounded-xl bg-[#fff8e7] p-3 text-[11px] leading-relaxed text-[#7e662f]"><Scale className="mb-2 h-4 w-4 text-[#c58a00]" /> <strong>SIMULATED WEIGHBRIDGE INPUT.</strong> This demo uses manual software entry. A future authorized hardware provider can replace this adapter.</div><div className="grid gap-3 sm:grid-cols-2"><label className="block"><span className="mb-1.5 block text-xs font-extrabold text-[#405b49]">Gross weight (kg)</span><input type="number" min="0" value={grossKg} onChange={(event) => setGrossKg(event.target.value)} className="h-11 w-full rounded-xl border border-[#dfe8de] px-3 text-sm font-extrabold text-[#294334] outline-none focus:border-[#6da078]" /></label><label className="block"><span className="mb-1.5 block text-xs font-extrabold text-[#405b49]">Tare weight (kg)</span><input type="number" min="0" value={tareKg} onChange={(event) => setTareKg(event.target.value)} className="h-11 w-full rounded-xl border border-[#dfe8de] px-3 text-sm font-extrabold text-[#294334] outline-none focus:border-[#6da078]" /></label></div><div className="grid grid-cols-3 gap-2 rounded-xl bg-[#f0f7ef] p-4 text-center"><div><div className="text-[10px] font-bold text-[#82978a]">Gross</div><div className="mt-1 text-sm font-extrabold text-[#294334]">{Number(grossKg || 0).toFixed(0)} kg</div></div><div><div className="text-[10px] font-bold text-[#82978a]">Tare</div><div className="mt-1 text-sm font-extrabold text-[#294334]">{Number(tareKg || 0).toFixed(0)} kg</div></div><div><div className="text-[10px] font-bold text-[#82978a]">Net</div><div className="mt-1 text-sm font-extrabold text-[#2f7d32]">{netKg.toFixed(0)} kg</div></div></div><button disabled={Number(tareKg || 0) > Number(grossKg || 0)} onClick={() => { setCompleted(true); onAction(`Weighment saved: ${quintals.toFixed(2)} quintals net.`); }} className="w-full rounded-xl bg-[#14532d] px-4 py-3.5 text-sm font-extrabold text-white disabled:cursor-not-allowed disabled:bg-[#a5b6a8]">Save weighment · {quintals.toFixed(2)} qtl</button>{Number(tareKg || 0) > Number(grossKg || 0) && <div className="text-xs font-bold text-[#b42318]">Tare weight cannot be greater than gross weight.</div>}</div>}{isQuality && <div className="space-y-4"><div className="rounded-xl bg-[#eaf3fb] p-3 text-[11px] leading-relaxed text-[#4d7191]"><ClipboardCheck className="mb-2 h-4 w-4 text-[#4d82ad]" /> Transparent thresholds: moisture above 14% triggers a configured demo deduction.</div><label className="block"><span className="mb-1.5 block text-xs font-extrabold text-[#405b49]">Moisture (%)</span><input type="number" min="0" max="100" value={moisture} onChange={(event) => setMoisture(event.target.value)} className="h-11 w-full rounded-xl border border-[#dfe8de] px-3 text-sm font-extrabold text-[#294334] outline-none focus:border-[#6da078]" /></label><div className="grid gap-3 sm:grid-cols-2"><label className="block"><span className="mb-1.5 block text-xs font-extrabold text-[#405b49]">Foreign matter (%)</span><input type="number" defaultValue="1" className="h-11 w-full rounded-xl border border-[#dfe8de] px-3 text-sm font-extrabold text-[#294334] outline-none focus:border-[#6da078]" /></label><label className="block"><span className="mb-1.5 block text-xs font-extrabold text-[#405b49]">Damaged grain (%)</span><input type="number" defaultValue="1" className="h-11 w-full rounded-xl border border-[#dfe8de] px-3 text-sm font-extrabold text-[#294334] outline-none focus:border-[#6da078]" /></label></div><div className="rounded-xl border border-[#e4ebe3] p-4"><div className="flex justify-between text-xs"><span className="font-semibold text-[#718177]">Assessment result</span><strong className={Number(moisture) > 14 ? "text-[#8f6418]" : "text-[#2f7d32]"}>{Number(moisture) > 14 ? "ACCEPTED WITH DEDUCTION" : "ACCEPTED"}</strong></div><div className="mt-3 flex justify-between text-xs"><span className="font-semibold text-[#718177]">Quality deduction</span><strong className="text-[#294334]">{Number(moisture) > 14 ? "2%" : "0%"}</strong></div></div><button onClick={() => { setCompleted(true); onAction("Quality assessment saved and farmer notified."); }} className="w-full rounded-xl bg-[#14532d] px-4 py-3.5 text-sm font-extrabold text-white">Save quality assessment</button></div>}{!isWeighment && !isQuality && <div className="space-y-4"><div className="rounded-xl bg-[#f0f7ef] p-4"><div className="mb-4 text-xs font-extrabold text-[#294334]">Transparent MSP calculation</div><div className="space-y-3 text-xs"><div className="flex justify-between"><span className="text-[#718177]">Eligible quantity</span><strong className="text-[#294334]">{quintals.toFixed(2)} qtl</strong></div><div className="flex justify-between"><span className="text-[#718177]">Soybean MSP</span><strong className="text-[#294334]">₹5,328 / qtl</strong></div><div className="flex justify-between border-t border-[#dce9dc] pt-3"><span className="font-bold text-[#567060]">Gross amount</span><strong className="text-[#294334]">₹{grossAmount.toFixed(0)}</strong></div><div className="flex justify-between"><span className="text-[#718177]">Quality deduction</span><strong className="text-[#8f6418]">− ₹{deduction.toFixed(0)}</strong></div><div className="flex justify-between border-t border-[#c9dfcb] pt-3 text-sm"><span className="font-extrabold text-[#2f5d3d]">Final payable</span><strong className="font-display text-lg font-extrabold text-[#14532d]">₹{finalAmount.toFixed(0)}</strong></div></div></div><div className="rounded-xl bg-[#fff8e7] p-3 text-[11px] leading-relaxed text-[#7e662f]"><HandCoins className="mb-2 h-4 w-4 text-[#c58a00]" /> <strong>DEMO PAYMENT.</strong> No real bank or DBT integration is connected. Payment is only marked paid after this demo action.</div><button onClick={() => { setCompleted(true); onAction("Demo payment processed. Receipt and notification generated."); }} className="w-full rounded-xl bg-[#14532d] px-4 py-3.5 text-sm font-extrabold text-white">Process demo payment · ₹{finalAmount.toFixed(0)}</button></div>}</div><div className="rounded-[20px] bg-[#f0f7ef] p-5"><div className="mb-5 flex items-center gap-2 text-[#356c4a]"><ShieldCheck className="h-4 w-4" /><span className="text-xs font-extrabold">Audit-safe workflow</span></div><div className="space-y-3 text-[11px] leading-relaxed text-[#64806b]"><div className="flex items-center gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-[#4e976c]" /> Inputs validated before saving</div><div className="flex items-center gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-[#4e976c]" /> Farmer sees the same calculation</div><div className="flex items-center gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-[#4e976c]" /> Every action creates an audit event</div></div><div className="mt-7 rounded-xl bg-white/70 p-3 text-[11px] leading-relaxed text-[#678072]">Offline entries are saved securely on this device and revalidated by the server when synced.</div></div></div></div>;
}

function WorkDesk({ title, onAction }: { title: string; onAction: (message: string) => void }) {
  const isPayment = title === "Payment release";
  return <div className="animate-rise-in"><SectionHeading eyebrow="Centre workflow" title={title} action="View audit trail" onAction={() => onAction("Audit trail opened for this desk.")} /><div className="grid gap-5 lg:grid-cols-[1fr_340px]"><div className="rounded-[20px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)]"><div className="mb-5 flex items-start justify-between"><div><div className="text-xs font-extrabold text-[#2b4535]">{isPayment ? "Lots ready for payment release" : "Pending tasks"}</div><div className="mt-1 text-[11px] font-medium text-[#87958b]">{isPayment ? "Verify the transparent calculation before release." : "Continue from where the last operator stopped."}</div></div><StatusPill tone="amber">7 pending</StatusPill></div>{["A-021 · Gopal Meena", "A-022 · Reena Bai", "A-023 · Sita Devi", "A-024 · Mohan Singh"].map((name, index) => <div key={name} className="flex items-center gap-3 border-t border-[#eef1ed] py-4"><span className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#edf4ec] text-[#4f8d62]">{isPayment ? <IndianRupee className="h-4 w-4" /> : title === "Quality checks" ? <ClipboardCheck className="h-4 w-4" /> : <Scale className="h-4 w-4" />}</span><div><div className="text-xs font-extrabold text-[#2d4637]">{name}</div><div className="mt-1 text-[10px] font-semibold text-[#93a097]">Soybean · {index + 1}8.5 qtl · 09:{12 + index * 4}</div></div><button onClick={() => onAction(`${name.split(" · ")[0]} opened in ${title}.`)} className="ml-auto inline-flex items-center gap-1 rounded-lg bg-[#f0f7ef] px-2.5 py-2 text-[10px] font-extrabold text-[#3c8155]">Open <ChevronRight className="h-3 w-3" /></button></div>)}</div><div className="rounded-[20px] bg-[#f0f7ef] p-5"><div className="mb-5 flex items-center gap-2 text-[#356c4a]"><ShieldCheck className="h-4 w-4" /><span className="text-xs font-extrabold">Transparent by default</span></div><div className="space-y-3 text-[11px] text-[#64806b]"><div className="flex items-center gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-[#4e976c]" /> Two-person verification enabled</div><div className="flex items-center gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-[#4e976c]" /> Farmer sees the same calculation</div><div className="flex items-center gap-2"><CheckCircle2 className="h-3.5 w-3.5 text-[#4e976c]" /> Every action is audit logged</div></div><button onClick={() => onAction("The centre transparency guide is ready.")} className="mt-7 text-[11px] font-extrabold text-[#34794f]">Read the centre guide <ArrowRight className="ml-1 inline h-3.5 w-3.5" /></button></div></div></div>;
}

function AdminOverview({ onAction }: { onAction: (message: string) => void }) {
  return <><div className="mb-6 flex flex-col justify-between gap-4 rounded-[20px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)] sm:flex-row sm:items-center sm:p-6"><div><div className="mb-1 text-[11px] font-bold uppercase tracking-widest text-[#8a7da9]">Sehore district · 24 September 2026</div><h2 className="font-display text-[25px] font-extrabold tracking-[-.04em] text-[#193329]">Operations at a glance.</h2><p className="mt-1 text-xs font-medium text-[#809087]">A clear, real-time view across 12 procurement centres.</p></div><button onClick={() => onAction("District data exported as CSV.")} className="inline-flex items-center gap-2 self-start rounded-xl bg-[#1e6b4b] px-3 py-2.5 text-xs font-extrabold text-white transition hover:bg-[#16583c] sm:self-auto"><Download className="h-4 w-4" /> Export report</button></div><div className="mb-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><MetricCard label="Farmers served" value="2,840" note="+14.2% this season" icon={UsersRound} tone="green" /><MetricCard label="Procured this season" value="18,420 qtl" note="92% of district target" icon={Sprout} tone="amber" /><MetricCard label="Payments released" value="₹9.8 Cr" note="98.4% on-time" icon={IndianRupee} tone="blue" /><MetricCard label="Centres online" value="11 / 12" note="1 centre syncing offline" icon={Network} tone="violet" /></div><div className="grid gap-5 lg:grid-cols-[1.15fr_.85fr]"><div className="rounded-[20px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)]"><SectionHeading eyebrow="Performance" title="Centre throughput" action="Compare centres" onAction={() => onAction("Centre comparison view opened.")} /><div className="space-y-4">{[{ name: "Bargaon · MP-04", value: 92, qtl: "2,412 qtl", color: "bg-[#4f986d]" }, { name: "Ashta · MP-02", value: 84, qtl: "2,108 qtl", color: "bg-[#6e9dca]" }, { name: "Ichhawar · MP-08", value: 76, qtl: "1,884 qtl", color: "bg-[#d7a64f]" }, { name: "Nasrullaganj · MP-07", value: 69, qtl: "1,622 qtl", color: "bg-[#9a82cf]" }].map((centre) => <div key={centre.name}><div className="mb-2 flex items-center justify-between text-xs"><span className="font-bold text-[#405d4a]">{centre.name}</span><span className="font-extrabold text-[#2d4637]">{centre.qtl}</span></div><div className="h-2 overflow-hidden rounded-full bg-[#eef2ed]"><div className={`h-full rounded-full ${centre.color}`} style={{ width: `${centre.value}%` }} /></div></div>)}</div></div><div className="rounded-[20px] border border-[#e3ebe1] bg-[#1e6b4b] p-5 text-white shadow-[0_18px_35px_rgba(30,107,75,.12)]"><div className="mb-5 flex items-center gap-2 text-[#b8ddbd]"><ShieldCheck className="h-4 w-4" /><span className="text-[10px] font-bold uppercase tracking-[.16em]">Trust & transparency</span></div><div className="text-[29px] font-display font-extrabold tracking-[-.05em]">96.8%</div><div className="mt-1 text-xs font-semibold text-[#d7ebd8]">Farmers who received a digital receipt</div><div className="my-6 h-px bg-white/15" /><div className="space-y-4">{[{ label: "Weighment disputes", value: "3", sub: "down 40%" }, { label: "Quality appeals", value: "7", sub: "all resolved" }, { label: "Avg. payment time", value: "1.8 days", sub: "target: 2 days" }].map((item) => <div key={item.label} className="flex items-center justify-between"><div><div className="text-xs font-bold text-[#d7ebd8]">{item.label}</div><div className="mt-1 text-[10px] text-[#9fc7a8]">{item.sub}</div></div><span className="text-sm font-extrabold text-[#f2d28d]">{item.value}</span></div>)}</div></div></div></>;
}

function AdminSection({ activeNav, onAction }: { activeNav: string; onAction: (message: string) => void }) {
  if (activeNav === "overview") return <AdminOverview onAction={onAction} />;
  if (activeNav === "reports") return <ReportsPanel onAction={onAction} />;
  return <div className="animate-rise-in"><SectionHeading eyebrow="District control" title={activeNav === "centres" ? "Centre performance" : activeNav === "transparency" ? "Transparency ledger" : "System settings"} action="Export" onAction={() => onAction("Export is ready.")} /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{["Bargaon · 92% target", "Ashta · 84% target", "Ichhawar · 76% target", "Appeals resolved · 98%", "Offline sync health · 99%", "Languages active · 5"].map((item, index) => <div key={item} className="rounded-[18px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)]"><div className="mb-4 flex h-9 w-9 items-center justify-center rounded-xl bg-[#edf4ec] text-[#4b8c61]"><ShieldCheck className="h-4 w-4" /></div><div className="text-sm font-extrabold text-[#2d4637]">{item}</div><div className="mt-2 text-[11px] leading-relaxed text-[#85948a]">{index % 2 === 0 ? "Above district benchmark this week." : "No action required at this time."}</div></div>)}</div></div>;
}

function ReportsPanel({ onAction }: { onAction: (message: string) => void }) {
  return <div className="animate-rise-in"><SectionHeading eyebrow="District intelligence" title="Reports & exports" action="Schedule report" onAction={() => onAction("Report scheduling is ready.")} /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{[{ title: "Daily procurement summary", desc: "Centre-wise arrivals, weights and payments", icon: ReceiptText }, { title: "MSP compliance report", desc: "Rate checks and exception tracking", icon: ShieldCheck }, { title: "Farmer service report", desc: "Reach, language and assisted access", icon: UsersRound }].map((report) => { const Icon = report.icon; return <button key={report.title} onClick={() => onAction(`${report.title} downloaded.`)} className="rounded-[18px] border border-[#e3ebe1] bg-white p-5 text-left shadow-[0_8px_24px_rgba(28,67,47,.035)] transition hover:-translate-y-0.5 hover:border-[#c8ddc9]"><div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-[#edf4ec] text-[#4b8c61]"><Icon className="h-5 w-5" /></div><div className="text-sm font-extrabold text-[#2d4637]">{report.title}</div><div className="mt-2 text-[11px] leading-relaxed text-[#85948a]">{report.desc}</div><div className="mt-5 inline-flex items-center gap-1 text-[11px] font-extrabold text-[#3e8157]">Download CSV <Download className="h-3.5 w-3.5" /></div></button>; })}</div></div>;
}

function AssistantOverview({ onAction }: { onAction: (message: string) => void }) {
  const [lookup, setLookup] = useState("");
  return <><div className="mb-6 rounded-[20px] border border-[#efdfd7] bg-[#fff7f3] p-5 shadow-[0_8px_24px_rgba(128,76,53,.04)] sm:p-6"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-center"><div><div className="mb-1 flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest text-[#b26e52]"><LifeBuoy className="h-3.5 w-3.5" /> Village assistant desk</div><h2 className="font-display text-[25px] font-extrabold tracking-[-.04em] text-[#50372d]">Make every visit easier.</h2><p className="mt-1 max-w-[510px] text-xs font-medium leading-relaxed text-[#987364]">Register, book and explain procurement in the farmer’s language — even when the network is unavailable.</p></div><div className="flex items-center gap-2"><button onClick={() => onAction("Voice-assisted mode enabled.")} className="inline-flex items-center gap-2 rounded-xl bg-[#d37e60] px-3 py-2.5 text-xs font-extrabold text-white shadow-[0_7px_16px_rgba(211,126,96,.18)]"><Mic className="h-4 w-4" /> Voice mode</button><button onClick={() => onAction("Help guide opened.")} className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#edd5cc] bg-white text-[#b7775e]"><CircleHelp className="h-4 w-4" /></button></div></div></div><div className="mb-7 grid gap-3 sm:grid-cols-3"><MetricCard label="Farmers assisted today" value="28" note="6 registrations · 22 bookings" icon={UsersRound} tone="green" /><MetricCard label="Offline records" value="4" note="Will sync when online" icon={CloudOff} tone="amber" /><MetricCard label="Languages available" value="5" note="Hindi · Marathi · English +" icon={Languages} tone="blue" /></div><div className="grid gap-5 lg:grid-cols-[.8fr_1.2fr]"><div><SectionHeading eyebrow="Do more" title="Quick assist" /><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">{[{ label: "Register a farmer", sub: "New Kisan ID and profile", icon: Plus }, { label: "Book on behalf", sub: "Choose centre and slot", icon: CalendarDays }, { label: "Scan farmer QR", sub: "Find an existing profile", icon: ScanLine }, { label: "Explain in local language", sub: "Use voice and picture guides", icon: Volume2 }].map((item) => { const Icon = item.icon; return <button key={item.label} onClick={() => onAction(`${item.label} opened.`)} className="group flex items-center gap-3 rounded-[16px] border border-[#e3ebe1] bg-white p-4 text-left shadow-[0_7px_22px_rgba(28,67,47,.03)] transition hover:-translate-y-0.5 hover:border-[#e8c9be]"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#fff0eb] text-[#bb765b]"><Icon className="h-[18px] w-[18px]" /></span><span><span className="block text-sm font-extrabold text-[#294334]">{item.label}</span><span className="mt-1 block text-[11px] font-medium text-[#87958b]">{item.sub}</span></span><ChevronRight className="ml-auto h-4 w-4 text-[#bdc8bf] transition group-hover:translate-x-0.5" /></button>; })}</div></div><div><SectionHeading eyebrow="Fast lookup" title="Find a farmer" action="Open full search" onAction={() => onAction("Full farmer search opened.")} /><div className="rounded-[20px] border border-[#e3ebe1] bg-white p-5 shadow-[0_8px_24px_rgba(28,67,47,.035)]"><div className="relative"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#9aa79e]" /><input value={lookup} onChange={(event) => setLookup(event.target.value)} placeholder="Name, phone or Kisan ID" className="h-11 w-full rounded-xl border border-[#dfe8de] bg-[#fbfcfa] pl-10 pr-3 text-xs font-semibold text-[#294334] outline-none transition placeholder:text-[#9aa79e] focus:border-[#72a37e] focus:ring-2 focus:ring-[#e0efe1]" /></div>{lookup ? <div className="mt-4 flex items-center gap-3 rounded-xl bg-[#f1f8f0] p-3"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#4f976c] text-xs font-extrabold text-white">SD</span><div><div className="text-xs font-extrabold text-[#2d4637]">Sita Devi</div><div className="mt-1 text-[10px] font-semibold text-[#819087]">KISAN-MP-008124 · Soybean · Bargaon</div></div><button onClick={() => onAction("Sita Devi’s profile opened.")} className="ml-auto text-[#3e8157]"><ChevronRight className="h-4 w-4" /></button></div> : <div className="mt-5 flex items-center justify-center gap-2 py-10 text-xs font-semibold text-[#9aa79e]"><QrCode className="h-4 w-4" /> Search or scan to begin</div>}<div className="mt-4 flex items-center gap-2 rounded-xl bg-[#fff7f3] p-3 text-[11px] text-[#956d5d]"><CloudOff className="h-3.5 w-3.5" /> Search also works with the last synced records offline.</div></div></div></div></>;
}

function AssistantSection({ activeNav, onAction }: { activeNav: string; onAction: (message: string) => void }) {
  if (activeNav === "overview") return <AssistantOverview onAction={onAction} />;
  const title = activeNav === "register" ? "Register a farmer" : activeNav === "booking" ? "Book on behalf of a farmer" : activeNav === "lookup" ? "Find a farmer" : "Offline sync centre";
  return <div className="animate-rise-in"><SectionHeading eyebrow="Assisted access" title={title} action="Need a guide?" onAction={() => onAction("Step-by-step guide opened.")} /><div className="rounded-[20px] border border-[#e3ebe1] bg-white p-6 shadow-[0_8px_24px_rgba(28,67,47,.035)]"><div className="mx-auto flex max-w-[510px] flex-col items-center py-8 text-center"><div className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#fff0eb] text-[#bb765b]"><UserRound className="h-7 w-7" /></div><h3 className="font-display text-xl font-extrabold tracking-[-.03em] text-[#2a4334]">{title}</h3><p className="mt-2 text-xs leading-relaxed text-[#849289]">This guided flow is designed for assisted digital access. Large controls, local language prompts and offline saving are enabled.</p><button onClick={() => onAction(`${title} started.`)} className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#d37e60] px-4 py-3 text-xs font-extrabold text-white shadow-[0_7px_16px_rgba(211,126,96,.18)]">Start guided flow <ArrowRight className="h-4 w-4" /></button></div></div></div>;
}

function Sidebar({ role, activeNav, onNav, onRole, open, onClose }: { role: Role; activeNav: string; onNav: (id: string) => void; onRole: (role: Role) => void; open: boolean; onClose: () => void }) {
  const meta = roleMeta[role];
  const { t } = useLanguage();
  const translatedNav = (id: string) => id === "overview" ? t(role === "farmer" ? "nav.dashboard" : role === "officer" ? "nav.overview" : role === "admin" ? "admin.dashboard" : "nav.assistDesk") : id === "book" ? t("nav.book") : id === "queue" ? t("nav.queue") : id === "payments" ? t("nav.payments") : id === "records" ? t("nav.records") : id === "weighment" ? t("nav.weighment") : id === "quality" ? t("nav.quality") : id === "payment" ? t("nav.paymentRelease") : id === "assist" ? t("nav.assistDesk") : id;
  return <><div className={`fixed inset-0 z-40 bg-[#173329]/35 backdrop-blur-[2px] transition-opacity lg:hidden ${open ? "opacity-100" : "pointer-events-none opacity-0"}`} onClick={onClose} /><aside className={`fixed inset-y-0 left-0 z-50 flex w-[260px] flex-col border-r border-[#e5ebe4] bg-[#fbfcfa] px-4 py-5 transition-transform duration-200 lg:static lg:z-auto lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}><div className="flex items-center justify-between px-2"><Logo /><button onClick={onClose} className="rounded-lg p-1.5 text-[#93a097] hover:bg-[#edf3ed] lg:hidden"><X className="h-4 w-4" /></button></div><div className="mt-7 rounded-[14px] border border-[#e5ebe4] bg-white p-3 shadow-[0_5px_15px_rgba(28,67,47,.03)]"><div className="mb-2 text-[9px] font-extrabold uppercase tracking-[.16em] text-[#93a097]">{t("common.profile")}</div><div className="relative"><select value={role} onChange={(e) => onRole(e.target.value as Role)} className="h-9 w-full appearance-none rounded-lg bg-[#f2f7f1] px-3 pr-8 text-xs font-extrabold text-[#31513d] outline-none"><option value="farmer">Farmer · Sita Devi</option><option value="officer">Centre Officer · Ramesh</option><option value="admin">Admin · Anita</option><option value="assistant">Village Assistant · Meena</option></select><ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#6e8976]" /></div><div className="mt-2 text-[10px] font-semibold text-[#9aa79d]">{t("common.demo")}</div></div><nav className="mt-7 flex-1 space-y-1">{navItems[role].map((item) => { const Icon = item.icon; const active = item.id === activeNav; return <button key={item.id} onClick={() => { onNav(item.id); onClose(); }} className={`group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-xs font-bold transition ${active ? "bg-[#e7f3e8] text-[#276b47]" : "text-[#718177] hover:bg-[#f0f4ef] hover:text-[#315a40]"}`}><Icon className={`h-[17px] w-[17px] ${active ? "text-[#2e8056]" : "text-[#97a49a] group-hover:text-[#5e8469]"}`} />{translatedNav(item.id)}{active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[#4d986c]" />}</button>; })}</nav><div className="space-y-3 border-t border-[#e6ece5] pt-4"><button onClick={() => toast.info(t("offline.offline"))} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-xs font-bold text-[#718177] hover:bg-[#f0f4ef]"><WifiOff className="h-4 w-4 text-[#8ea094]" /> {t("offline.offline")}</button><button onClick={() => toast.info(t("common.help"))} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-xs font-bold text-[#718177] hover:bg-[#f0f4ef]"><LifeBuoy className="h-4 w-4 text-[#8ea094]" /> {t("common.help")}</button><div className="flex items-center gap-3 rounded-xl bg-[#f0f5ef] p-3"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#dcebdc] text-[10px] font-extrabold text-[#477b57]">{meta.short}</div><div className="min-w-0"><div className="truncate text-xs font-extrabold text-[#34513e]">{meta.name}</div><div className="truncate text-[10px] font-semibold text-[#94a197]">{meta.location}</div></div><MoreHorizontal className="ml-auto h-4 w-4 shrink-0 text-[#9aa79e]" /></div></div></aside></>;
}

export default function Home() {
  const [, navigate] = useLocation();
  const [role, setRole] = useState<Role>(() => { try { const session = JSON.parse(localStorage.getItem("dhaanya-demo-session") ?? "{}"); return session.role === "centre_officer" ? "officer" : session.role === "admin" ? "admin" : session.role === "village_assistant" ? "assistant" : "farmer"; } catch { return "farmer"; } });
  const [activeNav, setActiveNav] = useState("overview");
  const [mobileOpen, setMobileOpen] = useState(false);
  const { language, setLanguage, t } = useLanguage();
  const [verifiedFarmer, setVerifiedFarmer] = useState(false);
  const verificationReference = (() => { try { return (JSON.parse(localStorage.getItem("dhaanya-verification") ?? "{}") as { reference?: string }).reference ?? ""; } catch { return ""; } })();
  const { data: verificationStatus } = trpc.identity.status.useQuery({ reference: verificationReference }, { enabled: role === "farmer" && verificationReference.length > 0 });
  const [queue, setQueue] = useState(initialQueue);
  const [checkedIn, setCheckedIn] = useState<number[]>([]);
  const meta = roleMeta[role];
  const currentNav = useMemo(() => navItems[role].find((item) => item.id === activeNav) ?? navItems[role][0], [role, activeNav]);
  useEffect(() => {
    setVerifiedFarmer(role === "farmer" && verificationStatus?.status === "VERIFIED");
  }, [role, verificationStatus?.status]);

  const handleRoleChange = (nextRole: Role) => {
    const session = JSON.parse(localStorage.getItem("dhaanya-demo-session") ?? "null") as { role?: string } | null;
    const allowedRole = session?.role === "centre_officer" ? "officer" : session?.role === "village_assistant" ? "assistant" : session?.role;
    if (allowedRole && allowedRole !== nextRole) { toast.error("Access denied"); return; }
    setRole(nextRole);
    setActiveNav("overview");
    toast.success(`Switched to ${roleMeta[nextRole].label} view`);
  };

  const handleNav = (id: string) => setActiveNav(id);
  const handleAction = (message: string) => toast.success(message, { duration: 3200 });
  const handleLogout = () => { toast.success(t("common.logout")); localStorage.removeItem("dhaanya-demo-session"); navigate("/"); };
  const cycleLanguage = () => {
    const next = languageOptions[(languageOptions.findIndex((item) => item.code === language) + 1) % languageOptions.length].code;
    setLanguage(next);
    toast.success(`${languageOptions.find((item) => item.code === next)?.native} selected`);
  };
  const handleVoice = () => {
    const supported = listenForCommand((command) => {
      const normalized = command.toLowerCase();
      if (normalized.includes("book")) setActiveNav("book");
      else if (normalized.includes("token") || normalized.includes("queue")) setActiveNav("queue");
      else if (normalized.includes("payment")) setActiveNav("payments");
      else toast.info(`Heard: ${command}`);
    }, language);
    if (!supported) {
      const spoken = speak("You can say book my slot, show my token, or check my payment.", language);
      if (!spoken) toast.info("Voice assistance is unavailable on this device.");
    } else toast.info("Listening… try saying book my slot or show my token.");
  };
  const handleCheckIn = (id: number) => {
    setCheckedIn((current) => [...current, id]);
    setQueue((current) => current.map((item) => item.id === id ? { ...item, status: "Quality" } : item));
    toast.success("Farmer checked in. Weighment desk notified.");
  };

  const navTitle = currentNav?.id === "overview" ? t(role === "farmer" ? "nav.dashboard" : role === "officer" ? "nav.overview" : role === "admin" ? "admin.dashboard" : "nav.assistDesk") : t(`nav.${currentNav?.id ?? "dashboard"}`);
  return <div className="min-h-screen bg-[#f7f8f4] text-[#17231d] farmland-pattern"><div className="flex min-h-screen"><Sidebar role={role} activeNav={activeNav} onNav={handleNav} onRole={handleRoleChange} open={mobileOpen} onClose={() => setMobileOpen(false)} /><main className="min-w-0 flex-1"><header className="sticky top-0 z-30 border-b border-[#e6ece5]/80 bg-[#f7f8f4]/90 px-4 py-4 backdrop-blur-xl sm:px-6 lg:px-8"><div className="flex items-center justify-between gap-3"><div className="flex min-w-0 items-center gap-3"><button onClick={() => setMobileOpen(true)} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-[#e0e8df] bg-white text-[#56705e] lg:hidden"><Menu className="h-4 w-4" /></button><div className="min-w-0"><div className="hidden items-center gap-2 text-[10px] font-bold uppercase tracking-[.16em] text-[#94a198] sm:flex"><span>{meta.label}</span>{verifiedFarmer && <span className="rounded-full bg-[#e7f3e8] px-2 py-1 text-[9px] tracking-normal text-[#2f7d32]">✓ {t("profile.verified")}</span>}</div><h1 className="truncate font-display text-[19px] font-extrabold tracking-[-.03em] text-[#1d3829] sm:text-[21px]">{navTitle}</h1></div></div><div className="flex items-center gap-2 sm:gap-3"><span className="hidden rounded-full bg-[#fff1d4] px-2.5 py-1.5 text-[9px] font-extrabold tracking-wider text-[#8a641a] sm:inline-flex">{t("common.demo")}</span><button onClick={cycleLanguage} aria-label="Change language" className="hidden items-center gap-1.5 rounded-xl border border-[#dfe8df] bg-white px-3 py-2 text-[11px] font-extrabold text-[#55705e] transition hover:border-[#bfd3c0] sm:flex"><Languages className="h-3.5 w-3.5" /> {languageOptions.find((item) => item.code === language)?.native}</button><button onClick={handleVoice} aria-label="Voice assistance" className="hidden h-9 w-9 items-center justify-center rounded-xl border border-[#dfe8df] bg-white text-[#708278] transition hover:border-[#bfd3c0] sm:flex"><Mic className="h-4 w-4" /></button><NotificationCenter /><div className="hidden h-8 w-px bg-[#e0e8df] sm:block" /><div className="hidden items-center gap-2 sm:flex"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#e3eedf] text-[10px] font-extrabold text-[#477b57]">{meta.short}</div><div className="hidden text-left xl:block"><div className="text-[11px] font-extrabold text-[#36513f]">{meta.name}</div><div className="text-[10px] font-semibold text-[#95a198]">{meta.location}</div></div></div></div></div></header><div className="mx-auto max-w-[1420px] px-4 py-5 sm:px-6 sm:py-6 lg:px-8 lg:py-7"><OfflineBanner onLearn={() => toast.info("Your activity is stored locally and syncs automatically when connectivity returns.")} />{role === "farmer" && <FarmerSection activeNav={activeNav} onAction={handleAction} onNav={handleNav} />}{role === "officer" && <OfficerSection activeNav={activeNav} queue={queue} checkedIn={checkedIn} onCheckIn={handleCheckIn} onAction={handleAction} />}{role === "admin" && <AdminSection activeNav={activeNav} onAction={handleAction} />}{role === "assistant" && <AssistantSection activeNav={activeNav} onAction={handleAction} />}</div></main></div>{role === "farmer" && <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-[#e0e8df] bg-white/95 px-2 py-2 shadow-[0_-8px_22px_rgba(28,67,47,.08)] backdrop-blur sm:hidden" aria-label="Farmer navigation"><button onClick={() => handleNav("overview")} className={`flex flex-col items-center gap-1 py-1 text-[9px] font-extrabold ${activeNav === "overview" ? "text-[#14532d]" : "text-[#89978e]"}`}><Gauge className="h-4 w-4" />{t("nav.dashboard")}</button><button onClick={() => handleNav("book")} className={`flex flex-col items-center gap-1 py-1 text-[9px] font-extrabold ${activeNav === "book" ? "text-[#14532d]" : "text-[#89978e]"}`}><CalendarDays className="h-4 w-4" />{t("nav.book")}</button><button onClick={() => handleNav("queue")} className={`flex flex-col items-center gap-1 py-1 text-[9px] font-extrabold ${activeNav === "queue" ? "text-[#14532d]" : "text-[#89978e]"}`}><ListChecks className="h-4 w-4" />{t("nav.queue")}</button><button onClick={() => handleNav("payments")} className={`flex flex-col items-center gap-1 py-1 text-[9px] font-extrabold ${activeNav === "payments" ? "text-[#14532d]" : "text-[#89978e]"}`}><WalletCards className="h-4 w-4" />{t("nav.payments")}</button><button onClick={handleLogout} className="flex flex-col items-center gap-1 py-1 text-[9px] font-extrabold text-[#89978e]"><UserRound className="h-4 w-4" />{t("common.logout")}</button></nav>}<div className="fixed bottom-4 right-4 z-20 hidden sm:block"><button onClick={() => toast.info("Dhaanya is designed for farmers, not just smartphones. Call 1800-XXX-XXXX for assisted access.")} className="flex items-center gap-2 rounded-full border border-[#dce7dc] bg-white px-3 py-2 text-[10px] font-extrabold text-[#54705d] shadow-[0_8px_22px_rgba(28,67,47,.1)]"><Phone className="h-3.5 w-3.5 text-[#4d9467]" /> Assisted access line</button></div></div>;
}

function BellIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M13.7 21a2 2 0 0 1-3.4 0" /></svg>;
}
