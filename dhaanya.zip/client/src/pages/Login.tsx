import { useState } from "react";
import { ArrowRight, CheckCircle2, Leaf, Languages, ShieldCheck, UsersRound } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { languageOptions } from "@/lib/i18n";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

type DemoRole = "farmer" | "officer" | "admin" | "assistant";
const accounts: { role: DemoRole; email: string; labelKey: string; descriptionKey: string }[] = [
  { role: "farmer", email: "farmer@dhaanya.demo", labelKey: "roles.farmer", descriptionKey: "roles.farmerDesc" },
  { role: "officer", email: "BARGAON-PC-001", labelKey: "roles.officer", descriptionKey: "roles.officerDesc" },
  { role: "admin", email: "admin@dhaanya.demo", labelKey: "roles.admin", descriptionKey: "roles.adminDesc" },
  { role: "assistant", email: "assistant@dhaanya.demo", labelKey: "roles.assistant", descriptionKey: "roles.assistantDesc" },
];

export default function Login() {
  const [, navigate] = useLocation();
  const { language, setLanguage, t } = useLanguage();
  const [email, setEmail] = useState("farmer@dhaanya.demo");
  const [password, setPassword] = useState("password123");
  const [selectedRole, setSelectedRole] = useState<DemoRole>("farmer");
  const authenticate = trpc.auth.demoLogin.useMutation();
  const selectedLanguage = languageOptions.find((option) => option.code === language)?.native;

  const login = async () => {
    if (!email || !password) { toast.error(t("auth.email")); return; }
    try {
      const result = await authenticate.mutateAsync({ role: selectedRole === "officer" ? "centre_officer" : selectedRole === "assistant" ? "village_assistant" : selectedRole, identifier: email, password });
      localStorage.setItem("dhaanya-demo-session", JSON.stringify({ role: result.role, email: result.identifier, signedInAt: Date.now() }));
    } catch (error) { toast.error(error instanceof Error ? error.message : t("auth.invalid")); return; }
    toast.success(`${t(accounts.find((account) => account.role === selectedRole)?.labelKey ?? "roles.farmer")} · ${t("common.login")}`);
    const verified = Boolean(localStorage.getItem("dhaanya-verification"));
    navigate(selectedRole === "farmer" ? (localStorage.getItem("dhaanya-verification") ? "/" : "/verify-identity") : "/");
  };

  return <div className="min-h-screen bg-[#f8f6ef] px-4 py-8 sm:px-6"><div className="mx-auto grid min-h-[calc(100vh-4rem)] max-w-5xl overflow-hidden rounded-[28px] border border-[#e5e8df] bg-white shadow-[0_20px_60px_rgba(28,67,47,.11)] lg:grid-cols-[.9fr_1.1fr]"><div className="relative hidden overflow-hidden bg-[#14532d] p-10 text-white lg:block"><div className="relative z-10"><div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/12"><Leaf className="h-5 w-5" /></div><span className="font-display text-xl font-extrabold">Dhaanya</span></div><div className="mt-24 max-w-[360px]"><div className="mb-3 text-[10px] font-bold uppercase tracking-[.18em] text-[#cbdc9f]">{t("brand.tagline")}</div><h1 className="font-display text-4xl font-extrabold leading-[1.08] tracking-[-.05em]">{t("brand.fromHarvest")}</h1><p className="mt-5 text-sm leading-relaxed text-[#c9dfca]">{t("brand.tagline")}</p></div></div><div className="absolute -bottom-20 -right-20 h-80 w-80 rounded-full border-[40px] border-white/5" /></div><div className="p-6 sm:p-10"><div className="mb-8 flex items-center justify-between gap-3"><div className="lg:hidden"><div className="flex items-center gap-2 text-[#14532d]"><Leaf className="h-5 w-5" /><span className="font-display text-xl font-extrabold">Dhaanya</span></div></div><div className="flex items-center gap-2"><Languages className="h-4 w-4 text-[#6d8375]" /><select value={language} onChange={(event) => setLanguage(event.target.value as typeof language)} aria-label={t("common.language")} className="rounded-lg border border-[#e0e8df] bg-white px-2 py-1.5 text-xs font-extrabold text-[#55705e]"><option value="en">English</option><option value="hi">हिन्दी</option><option value="ta">தமிழ்</option><option value="pa">ਪੰਜਾਬੀ</option></select><Link href="/" className="text-xs font-extrabold text-[#6f8074] hover:text-[#14532d]">{t("common.back")}</Link></div></div><div className="mx-auto max-w-[430px]"><div className="mb-7"><div className="mb-2 text-[10px] font-bold uppercase tracking-[.16em] text-[#8a988f]">{t("auth.secureDemo")}</div><h2 className="font-display text-3xl font-extrabold tracking-[-.05em] text-[#1f2937]">{t("auth.welcome")}</h2><p className="mt-2 text-sm leading-relaxed text-[#7e8d82]">{t("auth.roleHint")}</p></div><div className="mb-5 grid gap-2 sm:grid-cols-2">{accounts.map((account) => <button key={account.role} onClick={() => { setSelectedRole(account.role); setEmail(account.email); }} className={`rounded-xl border p-3 text-left transition ${selectedRole === account.role ? "border-[#71a37d] bg-[#f0f7ef] ring-2 ring-[#e2efe2]" : "border-[#e4eae3] hover:border-[#bfd5c1]"}`}><div className="flex items-center gap-2"><span className={`flex h-7 w-7 items-center justify-center rounded-lg ${selectedRole === account.role ? "bg-[#d9edd9] text-[#2d8055]" : "bg-[#f1f4f0] text-[#84958b]"}`}>{account.role === "farmer" ? <Leaf className="h-3.5 w-3.5" /> : account.role === "admin" ? <ShieldCheck className="h-3.5 w-3.5" /> : <UsersRound className="h-3.5 w-3.5" />}</span><span className="text-xs font-extrabold text-[#36513f]">{t(account.labelKey)}</span></div><div className="mt-2 text-[10px] leading-relaxed text-[#87958b]">{t(account.descriptionKey)}</div></button>)}</div><div className="space-y-4"><label className="block"><span className="mb-1.5 block text-xs font-extrabold text-[#405b49]">{t("auth.email")}</span><input value={email} onChange={(event) => setEmail(event.target.value)} className="h-11 w-full rounded-xl border border-[#dfe8de] px-3 text-sm font-semibold text-[#294334] outline-none focus:border-[#6da078] focus:ring-2 focus:ring-[#e4f0e4]" /></label><label className="block"><span className="mb-1.5 block text-xs font-extrabold text-[#405b49]">{t("auth.password")}</span><input type="password" value={password} onChange={(event) => setPassword(event.target.value)} className="h-11 w-full rounded-xl border border-[#dfe8de] px-3 text-sm font-semibold text-[#294334] outline-none focus:border-[#6da078] focus:ring-2 focus:ring-[#e4f0e4]" /></label><button onClick={login} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#14532d] px-4 py-3.5 text-sm font-extrabold text-white shadow-[0_8px_18px_rgba(20,83,45,.2)] transition hover:bg-[#0d4122] active:scale-[.99]">{t("auth.signIn")} <ArrowRight className="h-4 w-4" /></button></div><div className="mt-5 flex items-start gap-2 rounded-xl bg-[#fff8e7] p-3 text-[11px] leading-relaxed text-[#7d642e]"><CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#c58a00]" /><span>{t("auth.demoCredentials")}</span></div><div className="mt-5 text-center text-[11px] font-semibold text-[#96a29a]">{t("auth.newFarmer")} <button onClick={() => navigate("/register")} className="font-extrabold text-[#34784f]">{t("auth.register")}</button></div><div className="mt-3 text-center text-[11px] font-semibold text-[#96a29a]">{selectedLanguage}</div></div></div></div></div>;
}
