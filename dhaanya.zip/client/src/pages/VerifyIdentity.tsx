import { useEffect, useState } from "react";
import { ArrowRight, CheckCircle2, Fingerprint, Languages, LockKeyhole, ShieldCheck } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

function formatIdentity(value: string) {
  return value.replace(/\D/g, "").slice(0, 12).replace(/(\d{4})(?=\d)/g, "$1 ").trim();
}

export default function VerifyIdentity() {
  const [, navigate] = useLocation();
  const { language, setLanguage, t } = useLanguage();
  const [step, setStep] = useState(1);
  const [identityDigits, setIdentityDigits] = useState("");
  const [otp, setOtp] = useState("");
  const [reference, setReference] = useState("");
  const [verifiedAt, setVerifiedAt] = useState("");
  const [consent, setConsent] = useState(false);
  const startVerification = trpc.identity.start.useMutation();
  const verifyVerification = trpc.identity.verify.useMutation();

  useEffect(() => {
    const saved = localStorage.getItem("dhaanya-verification");
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as { reference?: string; verifiedAt?: string };
        if (parsed.reference) { setReference(parsed.reference); setVerifiedAt(parsed.verifiedAt ?? ""); setStep(3); }
      } catch { /* ignore invalid local demo state */ }
    }
  }, []);

  const start = async () => {
    if (identityDigits.length !== 12) { toast.error(t("identity.identityInput")); return; }
    if (!consent) { toast.error(t("identity.consentRequired")); return; }
    try {
      // Only the last four digits leave the browser; the raw identity is never persisted, logged, cached, or sent.
      const result = await startVerification.mutateAsync({ maskedReference: `XXXX XXXX ${identityDigits.slice(-4)}`, consent: true });
      setStep(2);
      toast.success(`${t("identity.generated")} · ${result.demoOtp}`);
    } catch { toast.error(t("identity.demoExplain")); }
  };

  const verify = async () => {
    if (otp.length !== 6) { toast.error(t("identity.enterOtp")); return; }
    try {
      const result = await verifyVerification.mutateAsync({ otp });
      if (result.status !== "VERIFIED" || !result.verificationReference) { toast.error(t("identity.invalidOtp")); return; }
      setReference(result.verificationReference);
      setVerifiedAt(result.verifiedAt ?? new Date().toISOString());
      localStorage.setItem("dhaanya-verification", JSON.stringify({ status: result.status, reference: result.verificationReference, provider: result.provider, verifiedAt: result.verifiedAt }));
      setStep(3);
    } catch { toast.error(t("identity.invalidOtp")); }
  };

  const title = step === 1 ? t("identity.title") : step === 2 ? t("identity.enterOtp") : t("identity.verified");
  return <div className="min-h-screen bg-[#f8f6ef] px-4 py-8 sm:px-6"><div className="mx-auto max-w-3xl"><div className="mb-6 flex items-center justify-between gap-3"><div className="flex items-center gap-2 text-[#14532d]"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#14532d] text-white"><Fingerprint className="h-4 w-4" /></div><span className="font-display text-lg font-extrabold">Dhaanya</span></div><div className="flex items-center gap-2"><Languages className="h-4 w-4 text-[#71857a]" /><select value={language} onChange={(event) => setLanguage(event.target.value as typeof language)} aria-label={t("common.language")} className="rounded-lg border border-[#e0e8df] bg-white px-2 py-1.5 text-xs font-extrabold text-[#55705e]"><option value="en">English</option><option value="hi">हिन्दी</option><option value="ta">தமிழ்</option><option value="pa">ਪੰਜਾਬੀ</option></select><span className="rounded-full bg-[#fff1d4] px-3 py-1.5 text-[10px] font-extrabold text-[#8a641a]">{t("identity.demoTitle")}</span></div></div><div className="rounded-[24px] border border-[#e3e8df] bg-white p-6 shadow-[0_18px_45px_rgba(28,67,47,.08)] sm:p-10"><div className="mx-auto max-w-[540px]"><div className="mb-8"><div className="mb-2 text-[10px] font-bold uppercase tracking-[.16em] text-[#8a988f]">{t("identity.step", { step })}</div><h1 className="font-display text-3xl font-extrabold tracking-[-.05em] text-[#1f2937]">{title}</h1><p className="mt-2 text-sm leading-relaxed text-[#7d8c82]">{step === 1 ? t("identity.demoExplain") : step === 2 ? t("identity.demoOtp") : t("identity.rawSafe")}</p></div><div className="mb-8 flex items-center gap-2">{[1, 2, 3].map((item) => <div key={item} className={`h-2 flex-1 rounded-full ${item <= step ? "bg-[#2f7d32]" : "bg-[#e5ece3]"}`} />)}</div>{step === 1 && <div className="space-y-5"><div className="rounded-xl bg-[#f0f7ef] p-4 text-xs leading-relaxed text-[#53715b]"><ShieldCheck className="mb-2 h-5 w-5 text-[#2f7d32]" /> <strong>{t("identity.demoTitle")}</strong><br />{t("identity.demoExplain")}</div><label className="block"><span className="mb-1.5 block text-xs font-extrabold text-[#405b49]">{t("identity.identityInput")}</span><input inputMode="numeric" maxLength={14} value={formatIdentity(identityDigits)} onChange={(event) => setIdentityDigits(event.target.value.replace(/\D/g, "").slice(0, 12))} placeholder="1234 5678 9012" className="h-12 w-full rounded-xl border border-[#dfe8de] px-3 text-lg font-extrabold tracking-[.16em] text-[#294334] outline-none focus:border-[#6da078] focus:ring-2 focus:ring-[#e4f0e4]" /><span className="mt-2 block text-[11px] text-[#7d8c82]">{t("identity.maskHint")}</span></label><label className="flex items-start gap-2 rounded-xl bg-[#fff8e7] p-3 text-[11px] leading-relaxed text-[#7d642e]"><input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} className="mt-0.5 h-4 w-4 rounded border-[#d9c18b]" /><span>{t("identity.consent")}</span></label><button disabled={startVerification.isPending} onClick={start} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#14532d] px-4 py-3.5 text-sm font-extrabold text-white disabled:opacity-60">{startVerification.isPending ? t("identity.generated") : t("identity.sendOtp")} <ArrowRight className="h-4 w-4" /></button></div>}{step === 2 && <div className="space-y-5"><div className="rounded-xl border border-[#e5ebe3] bg-[#fbfcfa] p-4 text-center"><div className="text-[10px] font-bold uppercase tracking-[.16em] text-[#91a097]">{t("identity.demoOtp")}</div><div className="mt-2 font-display text-2xl font-extrabold tracking-[.22em] text-[#14532d]">123456</div></div><label className="block"><span className="mb-1.5 block text-xs font-extrabold text-[#405b49]">{t("identity.enterOtp")}</span><input inputMode="numeric" maxLength={6} value={otp} onChange={(event) => setOtp(event.target.value.replace(/\D/g, ""))} placeholder="123456" className="h-12 w-full rounded-xl border border-[#dfe8de] px-3 text-lg font-extrabold tracking-[.3em] text-[#294334] outline-none focus:border-[#6da078] focus:ring-2 focus:ring-[#e4f0e4]" /></label><button disabled={verifyVerification.isPending} onClick={verify} className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#14532d] px-4 py-3.5 text-sm font-extrabold text-white disabled:opacity-60">{t("identity.verify")} <ArrowRight className="h-4 w-4" /></button><div className="grid grid-cols-2 gap-3"><button onClick={() => { setOtp(""); start(); }} className="rounded-xl border border-[#dfe8de] px-3 py-3 text-xs font-extrabold text-[#55705e]">{t("identity.resend")}</button><button onClick={() => { setStep(1); setOtp(""); }} className="rounded-xl border border-[#dfe8de] px-3 py-3 text-xs font-extrabold text-[#55705e]">{t("identity.changeIdentity")}</button></div></div>}{step === 3 && <div className="text-center"><div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#e5f4e6] text-[#2f7d32]"><CheckCircle2 className="h-8 w-8" /></div><h2 className="mt-5 font-display text-2xl font-extrabold text-[#234232]">{t("identity.verified")}</h2><div className="mx-auto mt-4 max-w-[330px] rounded-xl bg-[#f0f7ef] p-4 text-left text-xs"><div className="flex justify-between gap-4"><span className="font-semibold text-[#7c8d81]">{t("identity.status")}</span><strong className="text-[#2f7d32]">VERIFIED</strong></div><div className="mt-3 flex justify-between gap-4"><span className="font-semibold text-[#7c8d81]">{t("identity.reference")}</span><strong className="break-all text-[#294334]">{reference}</strong></div><div className="mt-3 flex justify-between gap-4"><span className="font-semibold text-[#7c8d81]">{t("identity.provider")}</span><strong className="text-[#294334]">DEMO</strong></div><div className="mt-3 flex justify-between gap-4"><span className="font-semibold text-[#7c8d81]">{t("identity.date")}</span><strong className="text-right text-[#294334]">{verifiedAt ? new Date(verifiedAt).toLocaleDateString() : new Date().toLocaleDateString()}</strong></div><div className="mt-3 flex items-center gap-2 text-[10px] leading-relaxed text-[#71847a]"><LockKeyhole className="h-3.5 w-3.5 shrink-0" /> {t("identity.rawSafe")}</div></div><button onClick={() => navigate("/land-verification")} className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-[#14532d] px-4 py-3.5 text-sm font-extrabold text-white">{t("profile.title")} <ArrowRight className="h-4 w-4" /></button></div>}</div></div></div></div>;
}
