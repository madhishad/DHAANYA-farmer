export type SupportedLanguage = "en" | "hi" | "ta" | "pa";

export const languageOptions: { code: SupportedLanguage; label: string; native: string }[] = [
  { code: "en", label: "English", native: "English" },
  { code: "hi", label: "Hindi", native: "हिन्दी" },
  { code: "ta", label: "Tamil", native: "தமிழ்" },
  { code: "pa", label: "Punjabi", native: "ਪੰਜਾਬੀ" },
];

const dictionaries: Record<SupportedLanguage, Record<string, string>> = {
  en: { dashboard: "My dashboard", bookSlot: "Book a slot", queue: "My queue token", payments: "Payments", offline: "Offline — Changes saved on this device", sync: "All changes synced", demo: "DEMO MODE", verified: "Verified farmer", help: "Help & support" },
  hi: { dashboard: "मेरा डैशबोर्ड", bookSlot: "स्लॉट बुक करें", queue: "मेरा कतार टोकन", payments: "भुगतान", offline: "ऑफलाइन — बदलाव इस डिवाइस पर सहेजे गए", sync: "सभी बदलाव सिंक हो गए", demo: "डेमो मोड", verified: "सत्यापित किसान", help: "सहायता और समर्थन" },
  ta: { dashboard: "என் டாஷ்போர்டு", bookSlot: "ஸ்லாட் முன்பதிவு", queue: "என் வரிசை டோக்கன்", payments: "பணம்", offline: "ஆஃப்லைன் — மாற்றங்கள் இந்த சாதனத்தில் சேமிக்கப்பட்டது", sync: "அனைத்து மாற்றங்களும் ஒத்திசைக்கப்பட்டன", demo: "டெமோ நிலை", verified: "சரிபார்க்கப்பட்ட விவசாயி", help: "உதவி மற்றும் ஆதரவு" },
  pa: { dashboard: "ਮੇਰਾ ਡੈਸ਼ਬੋਰਡ", bookSlot: "ਸਲਾਟ ਬੁੱਕ ਕਰੋ", queue: "ਮੇਰਾ ਕਤਾਰ ਟੋਕਨ", payments: "ਭੁਗਤਾਨ", offline: "ਆਫ਼ਲਾਈਨ — ਤਬਦੀਲੀਆਂ ਇਸ ਡਿਵਾਈਸ 'ਤੇ ਸੁਰੱਖਿਅਤ", sync: "ਸਾਰੀਆਂ ਤਬਦੀਲੀਆਂ ਸਿੰਕ ਹੋ ਗਈਆਂ", demo: "ਡੈਮੋ ਮੋਡ", verified: "ਤਸਦੀਕਸ਼ੁਦਾ ਕਿਸਾਨ", help: "ਮਦਦ ਅਤੇ ਸਹਾਇਤਾ" },
};

export function translate(language: SupportedLanguage, key: string) {
  return dictionaries[language][key] ?? dictionaries.en[key] ?? key;
}

export function speak(text: string, language: SupportedLanguage = "en") {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return false;
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = language === "hi" ? "hi-IN" : language === "ta" ? "ta-IN" : language === "pa" ? "pa-IN" : "en-IN";
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utterance);
  return true;
}

type VoiceResultEvent = { results: ArrayLike<ArrayLike<{ transcript: string }>> };
type VoiceRecognition = { lang: string; onresult: ((event: VoiceResultEvent) => void) | null; start: () => void };
type VoiceRecognitionConstructor = new () => VoiceRecognition;

export function listenForCommand(onResult: (text: string) => void, language: SupportedLanguage = "en") {
  const speechWindow = window as Window & { webkitSpeechRecognition?: VoiceRecognitionConstructor; SpeechRecognition?: VoiceRecognitionConstructor };
  const Recognition = speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition;
  if (!Recognition) return false;
  const recognition = new Recognition();
  recognition.lang = language === "hi" ? "hi-IN" : language === "ta" ? "ta-IN" : language === "pa" ? "pa-IN" : "en-IN";
  recognition.onresult = (event: VoiceResultEvent) => onResult(event.results[0]?.[0]?.transcript ?? "");
  recognition.start();
  return true;
}
