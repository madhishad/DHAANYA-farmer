export type SyncStatus = "PENDING_SYNC" | "SYNCING" | "SYNCED" | "SYNC_FAILED";

export type OfflineTransaction = {
  localTransactionId: string;
  centreId: string;
  userId: string;
  operationType: string;
  payload: unknown;
  createdAt: number;
  syncStatus: SyncStatus;
  retryCount: number;
  lastError?: string;
};

const DB_NAME = "dhaanya-offline";
const STORE_NAME = "transactions";

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB is unavailable on this device."));
      return;
    }
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE_NAME, { keyPath: "localTransactionId" });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Could not open offline storage."));
  });
}

export async function enqueueOfflineTransaction(input: Omit<OfflineTransaction, "createdAt" | "syncStatus" | "retryCount">) {
  const transaction: OfflineTransaction = { ...input, createdAt: Date.now(), syncStatus: "PENDING_SYNC", retryCount: 0 };
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const request = db.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME).put(transaction);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error ?? new Error("Could not save offline transaction."));
  });
  db.close();
  return transaction;
}

export async function listOfflineTransactions(): Promise<OfflineTransaction[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).getAll();
    request.onsuccess = () => { db.close(); resolve(request.result as OfflineTransaction[]); };
    request.onerror = () => { db.close(); reject(request.error ?? new Error("Could not read offline transactions.")); };
  });
}

export async function markTransactionStatus(localTransactionId: string, syncStatus: SyncStatus, lastError?: string) {
  const db = await openDatabase();
  const store = db.transaction(STORE_NAME, "readwrite").objectStore(STORE_NAME);
  const current = await new Promise<OfflineTransaction | undefined>((resolve, reject) => {
    const request = store.get(localTransactionId);
    request.onsuccess = () => resolve(request.result as OfflineTransaction | undefined);
    request.onerror = () => reject(request.error);
  });
  if (current) store.put({ ...current, syncStatus, lastError, retryCount: syncStatus === "SYNC_FAILED" ? current.retryCount + 1 : current.retryCount });
  db.close();
}
