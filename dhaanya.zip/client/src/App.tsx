import { useEffect } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Login from "@/pages/Login";
import RoleLogin from "@/pages/RoleLogin";
import Landing from "@/pages/Landing";
import Register from "@/pages/Register";
import VerifyIdentity from "@/pages/VerifyIdentity";
import ProfileSetup from "@/pages/ProfileSetup";
import LandVerification from "@/pages/LandVerification";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import PwaStatus from "./components/PwaStatus";
import { LanguageProvider } from "./contexts/LanguageContext";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import CentreDetails from "@/pages/CentreDetails";
import { toast } from "sonner";

function ProtectedDashboard({ expectedRole, children }: { expectedRole: string; children: React.ReactNode }) {
  const [location, navigate] = useLocation();
  useEffect(() => {
    const raw = localStorage.getItem("dhaanya-demo-session");
    const session = raw ? JSON.parse(raw) as { role?: string } : null;
    if (!session?.role) { navigate("/login"); return; }
    if (session.role !== expectedRole) {
      toast.error("Access denied");
      const own = session.role === "farmer" ? "/farmer/dashboard" : session.role === "centre_officer" ? "/centre/dashboard" : session.role === "admin" ? "/admin/dashboard" : "/assistant/dashboard";
      if (location !== own) navigate(own);
    }
  }, [expectedRole, location, navigate]);
  const raw = localStorage.getItem("dhaanya-demo-session");
  const session = raw ? JSON.parse(raw) as { role?: string } : null;
  if (!session?.role || session.role !== expectedRole) return null;
  return <>{children}</>;
}

function Router() {
  return <Switch>
    <Route path="/" component={Landing} />
    <Route path="/login" component={Login} />
    <Route path="/login/farmer" component={RoleLogin} />
    <Route path="/login/centre" component={RoleLogin} />
    <Route path="/login/admin" component={RoleLogin} />
    <Route path="/login/assistant" component={RoleLogin} />
    <Route path="/register" component={Register} />
    <Route path="/register/farmer" component={Register} />
    <Route path="/verify-identity" component={VerifyIdentity} />
    <Route path="/land-verification" component={LandVerification} />
    <Route path="/profile-setup" component={ProfileSetup} />
    <Route path="/farmer/dashboard"><ProtectedDashboard expectedRole="farmer"><Home /></ProtectedDashboard></Route>
    <Route path="/farmer/book"><ProtectedDashboard expectedRole="farmer"><Home /></ProtectedDashboard></Route>
    <Route path="/farmer/queue"><ProtectedDashboard expectedRole="farmer"><Home /></ProtectedDashboard></Route>
    <Route path="/farmer/payments"><ProtectedDashboard expectedRole="farmer"><Home /></ProtectedDashboard></Route>
    <Route path="/farmer/centre"><ProtectedDashboard expectedRole="farmer"><CentreDetails /></ProtectedDashboard></Route>
    <Route path="/centre/dashboard"><ProtectedDashboard expectedRole="centre_officer"><Home /></ProtectedDashboard></Route>
    <Route path="/admin/dashboard"><ProtectedDashboard expectedRole="admin"><Home /></ProtectedDashboard></Route>
    <Route path="/assistant/dashboard"><ProtectedDashboard expectedRole="village_assistant"><Home /></ProtectedDashboard></Route>
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><LanguageProvider><TooltipProvider><Toaster position="top-right" /><PwaStatus /><Router /></TooltipProvider></LanguageProvider></ThemeProvider></ErrorBoundary>;
}

export default App;
