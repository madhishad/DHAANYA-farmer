import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import en from "@/locales/en.json";
import hi from "@/locales/hi.json";
import ta from "@/locales/ta.json";
import pa from "@/locales/pa.json";
import type { SupportedLanguage } from "@/lib/i18n";

const dictionaries = { en, hi, ta, pa } as const;
type LanguageContextValue = { language: SupportedLanguage; setLanguage: (language: SupportedLanguage) => void; t: (key: string, vars?: Record<string, string | number>) => string };
const LanguageContext = createContext<LanguageContextValue | null>(null);

function lookup(dictionary: Record<string, unknown>, key: string): string | undefined {
  return key.split(".").reduce<unknown>((value, segment) => value && typeof value === "object" ? (value as Record<string, unknown>)[segment] : undefined, dictionary) as string | undefined;
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    const saved = typeof window !== "undefined" ? window.localStorage.getItem("dhaanya-language") : null;
    return saved === "hi" || saved === "ta" || saved === "pa" ? saved : "en";
  });
  const setLanguage = (next: SupportedLanguage) => { setLanguageState(next); localStorage.setItem("dhaanya-language", next); };
  const value = useMemo<LanguageContextValue>(() => ({ language, setLanguage, t: (key, vars) => {
    const raw = lookup(dictionaries[language], key) ?? lookup(dictionaries.en, key) ?? key;
    return Object.entries(vars ?? {}).reduce((text, [name, replacement]) => text.replaceAll(`{${name}}`, String(replacement)), raw);
  } }), [language]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const value = useContext(LanguageContext);
  if (!value) throw new Error("useLanguage must be used inside LanguageProvider");
  return value;
}
