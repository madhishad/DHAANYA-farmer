import { useCallback, useEffect, useState } from "react";
import { CheckCircle2, Download, RefreshCw, WifiOff, X } from "lucide-react";
import { toast } from "sonner";
import { listOfflineTransactions, markTransactionStatus, type OfflineTransaction } from "@/lib/offline";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

type BeforeInstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };

export default function PwaStatus() {
  const { t } = useLanguage();
  const [online, setOnline] = useState(() => typeof navigator === "undefined" ? true : navigator.onLine);
  const [pending, setPending] = useState(0);
  const [syncing, setSyncing] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [dismissed, setDismissed] = useState(() => typeof localStorage !== "undefined" && localStorage.getItem("dhaanya-install-dismissed") === "true");
  const submitSync = trpc.sync.submit.useMutation();

  const updatePending = useCallback(() => listOfflineTransactions().then((items) => setPending(items.filter((item) => item.syncStatus !== "SYNCED").length)).catch(() => undefined), []);
  const syncNow = useCallback(async () => {
    if (!navigator.onLine || syncing) return;
    const items = await listOfflineTransactions().catch(() => [] as OfflineTransaction[]);
    const pendingItems = items.filter((item) => item.syncStatus !== "SYNCED");
    if (!pendingItems.length) { setPending(0); return; }
    setSyncing(true);
    pendingItems.forEach((item) => void markTransactionStatus(item.localTransactionId, "SYNCING"));
    try {
      const result = await submitSync.mutateAsync({ deviceId: localStorage.getItem("dhaanya-device-id") ?? "browser-device", transactions: pendingItems.map((item) => ({ localTransactionId: item.localTransactionId, operationType: item.operationType, payload: item.payload })) });
      await Promise.all(result.synced.map((id) => markTransactionStatus(id, "SYNCED")));
      await Promise.all(result.failed.map((id) => markTransactionStatus(id, "SYNC_FAILED", t("offline.failed"))));
      await updatePending();
      toast.success(result.conflicts.length ? t("offline.conflict") : t("offline.synced"));
    } catch { await Promise.all(pendingItems.map((item) => markTransactionStatus(item.localTransactionId, "SYNC_FAILED", t("offline.failed")))); await updatePending(); toast.error(t("offline.failed")); }
    finally { setSyncing(false); }
  }, [submitSync, syncing, t, updatePending]);

  useEffect(() => {
    if (!localStorage.getItem("dhaanya-device-id")) localStorage.setItem("dhaanya-device-id", crypto.randomUUID?.() ?? `device-${Date.now()}`);
    const onOffline = () => { setOnline(false); toast.warning(t("offline.offline")); };
    const onOnline = () => { setOnline(true); toast.success(t("offline.connection")); void syncNow(); };
    const onInstall = (event: Event) => { event.preventDefault(); setInstallPrompt(event as BeforeInstallPromptEvent); };
    window.addEventListener("offline", onOffline); window.addEventListener("online", onOnline); window.addEventListener("beforeinstallprompt", onInstall); updatePending();
    return () => { window.removeEventListener("offline", onOffline); window.removeEventListener("online", onOnline); window.removeEventListener("beforeinstallprompt", onInstall); };
  }, [syncNow, t, updatePending]);

  const install = async () => { if (!installPrompt) { toast.info(t("offline.installText")); return; } await installPrompt.prompt(); setInstallPrompt(null); };
  return <><div className={`fixed bottom-16 left-4 z-50 flex items-center gap-2 rounded-full border px-3 py-2 text-[10px] font-extrabold shadow-[0_8px_22px_rgba(28,67,47,.12)] backdrop-blur sm:bottom-4 ${online ? "border-[#d7e7d8] bg-[#f5fbf4] text-[#34734b]" : "border-[#ecd9aa] bg-[#fff8e7] text-[#8f681d]"}`} role="status" aria-live="polite">{online ? syncing ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" /> : <WifiOff className="h-3.5 w-3.5" />}{online ? syncing ? t("offline.syncingLabel") : pending > 0 ? `${pending} ${t("offline.syncing")}` : t("offline.online") : t("offline.offline")}</div>{installPrompt && !dismissed && <div className="fixed bottom-16 left-4 z-50 w-[min(340px,calc(100vw-2rem))] rounded-2xl border border-[#e0e9df] bg-white p-4 shadow-[0_16px_38px_rgba(28,67,47,.16)] sm:bottom-4"><div className="flex items-start gap-3"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#e7f3e8] text-[#2e8056]"><Download className="h-4 w-4" /></div><div className="min-w-0"><div className="text-xs font-extrabold text-[#294334]">{t("offline.install")}</div><p className="mt-1 text-[11px] leading-relaxed text-[#7e8d82]">{t("offline.installText")}</p><div className="mt-3 flex gap-2"><button onClick={install} className="rounded-lg bg-[#14532d] px-3 py-2 text-[10px] font-extrabold text-white">{t("common.continue")}</button><button onClick={() => { localStorage.setItem("dhaanya-install-dismissed", "true"); setDismissed(true); }} className="rounded-lg border border-[#e0e8df] px-3 py-2 text-[10px] font-extrabold text-[#698071]">{t("offline.notNow")}</button></div></div><button onClick={() => { localStorage.setItem("dhaanya-install-dismissed", "true"); setDismissed(true); }} aria-label={t("common.cancel")} className="text-[#a4afa7]"><X className="h-3.5 w-3.5" /></button></div></div>}</>;
}
