import { decimal, index, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "farmer", "centre_officer", "village_assistant", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const farmerProfiles = mysqlTable("farmer_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  farmerId: varchar("farmerId", { length: 32 }).notNull().unique(),
  village: varchar("village", { length: 120 }).notNull(),
  district: varchar("district", { length: 120 }).notNull(),
  state: varchar("state", { length: 120 }).notNull(),
  preferredLanguage: varchar("preferredLanguage", { length: 10 }).default("en").notNull(),
  crops: text("crops"),
  farmDetails: text("farmDetails"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({ userIdx: index("farmer_profiles_user_idx").on(table.userId) }));

export const identityVerifications = mysqlTable("identity_verifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  provider: varchar("provider", { length: 80 }).notNull(),
  status: mysqlEnum("status", ["PENDING", "OTP_SENT", "VERIFIED", "FAILED", "EXPIRED"]).default("PENDING").notNull(),
  verificationReference: varchar("verificationReference", { length: 64 }),
  maskedReference: varchar("maskedReference", { length: 32 }),
  consentTimestamp: timestamp("consentTimestamp"),
  verifiedAt: timestamp("verifiedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ userIdx: index("identity_verifications_user_idx").on(table.userId) }));

export const procurementCentres = mysqlTable("procurement_centres", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  location: varchar("location", { length: 200 }).notNull(),
  district: varchar("district", { length: 120 }).notNull(),
  state: varchar("state", { length: 120 }).notNull(),
  capacityPerDay: int("capacityPerDay").notNull(),
  operatingHours: varchar("operatingHours", { length: 80 }).notNull(),
  supportedCrops: text("supportedCrops"),
  status: mysqlEnum("status", ["ACTIVE", "INACTIVE"]).default("ACTIVE").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const timeSlots = mysqlTable("time_slots", {
  id: int("id").autoincrement().primaryKey(),
  centreId: int("centreId").notNull(),
  crop: varchar("crop", { length: 60 }).notNull(),
  slotDate: varchar("slotDate", { length: 20 }).notNull(),
  startTime: varchar("startTime", { length: 10 }).notNull(),
  endTime: varchar("endTime", { length: 10 }).notNull(),
  capacity: int("capacity").notNull(),
  booked: int("booked").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ centreDateIdx: index("time_slots_centre_date_idx").on(table.centreId, table.slotDate) }));

export const bookings = mysqlTable("bookings", {
  id: int("id").autoincrement().primaryKey(),
  bookingReference: varchar("bookingReference", { length: 32 }).notNull().unique(),
  farmerId: int("farmerId").notNull(),
  centreId: int("centreId").notNull(),
  timeSlotId: int("timeSlotId").notNull(),
  crop: varchar("crop", { length: 60 }).notNull(),
  status: mysqlEnum("status", ["BOOKED", "ARRIVED", "IN_QUEUE", "WEIGHMENT_PENDING", "QUALITY_PENDING", "PAYMENT_PENDING", "COMPLETED", "CANCELLED"]).default("BOOKED").notNull(),
  token: varchar("token", { length: 20 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({ farmerStatusIdx: index("bookings_farmer_status_idx").on(table.farmerId, table.status), centreStatusIdx: index("bookings_centre_status_idx").on(table.centreId, table.status) }));

export const queueEntries = mysqlTable("queue_entries", {
  id: int("id").autoincrement().primaryKey(),
  bookingId: int("bookingId").notNull().unique(),
  centreId: int("centreId").notNull(),
  position: int("position").notNull(),
  status: mysqlEnum("status", ["WAITING", "CALLED", "CHECKED_IN", "COMPLETED"]).default("WAITING").notNull(),
  estimatedWaitMinutes: int("estimatedWaitMinutes").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const weighmentRecords = mysqlTable("weighment_records", {
  id: int("id").autoincrement().primaryKey(),
  bookingId: int("bookingId").notNull().unique(),
  grossKg: decimal("grossKg", { precision: 10, scale: 2 }).notNull(),
  tareKg: decimal("tareKg", { precision: 10, scale: 2 }).notNull(),
  netKg: decimal("netKg", { precision: 10, scale: 2 }).notNull(),
  netQuintals: decimal("netQuintals", { precision: 10, scale: 2 }).notNull(),
  provider: varchar("provider", { length: 80 }).default("MockWeighbridgeProvider").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const qualityAssessments = mysqlTable("quality_assessments", {
  id: int("id").autoincrement().primaryKey(),
  bookingId: int("bookingId").notNull().unique(),
  moisturePct: decimal("moisturePct", { precision: 5, scale: 2 }).notNull(),
  foreignMatterPct: decimal("foreignMatterPct", { precision: 5, scale: 2 }).notNull(),
  damagedGrainPct: decimal("damagedGrainPct", { precision: 5, scale: 2 }).notNull(),
  result: mysqlEnum("result", ["ACCEPTED", "ACCEPTED_WITH_DEDUCTION", "REJECTED"]).notNull(),
  deductionPct: decimal("deductionPct", { precision: 5, scale: 2 }).default("0").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const mspRates = mysqlTable("msp_rates", {
  id: int("id").autoincrement().primaryKey(),
  crop: varchar("crop", { length: 60 }).notNull().unique(),
  ratePerQuintal: decimal("ratePerQuintal", { precision: 12, scale: 2 }).notNull(),
  effectiveFrom: timestamp("effectiveFrom").defaultNow().notNull(),
  updatedBy: int("updatedBy"),
});

export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  bookingId: int("bookingId").notNull().unique(),
  farmerId: int("farmerId").notNull(),
  eligibleQuantity: decimal("eligibleQuantity", { precision: 10, scale: 2 }).notNull(),
  mspPerQuintal: decimal("mspPerQuintal", { precision: 12, scale: 2 }).notNull(),
  grossAmount: decimal("grossAmount", { precision: 14, scale: 2 }).notNull(),
  deductionAmount: decimal("deductionAmount", { precision: 14, scale: 2 }).default("0").notNull(),
  finalAmount: decimal("finalAmount", { precision: 14, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["PAYMENT_PENDING", "PROCESSING", "PAID", "FAILED"]).default("PAYMENT_PENDING").notNull(),
  provider: varchar("provider", { length: 80 }).default("MockPaymentProvider").notNull(),
  transactionReference: varchar("transactionReference", { length: 64 }),
  processedAt: timestamp("processedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  message: text("message").notNull(),
  channel: mysqlEnum("channel", ["IN_APP", "SMS", "EMAIL", "VOICE"]).default("IN_APP").notNull(),
  status: mysqlEnum("status", ["UNREAD", "READ", "FAILED"]).default("UNREAD").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  actor: int("actor").notNull(),
  role: varchar("role", { length: 40 }).notNull(),
  action: varchar("action", { length: 80 }).notNull(),
  entity: varchar("entity", { length: 80 }).notNull(),
  entityId: varchar("entityId", { length: 64 }).notNull(),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ entityIdx: index("audit_logs_entity_idx").on(table.entity, table.entityId) }));

export const syncTransactions = mysqlTable("sync_transactions", {
  id: int("id").autoincrement().primaryKey(),
  localTransactionId: varchar("localTransactionId", { length: 64 }).notNull().unique(),
  userId: int("userId").notNull(),
  centreId: int("centreId"),
  operationType: varchar("operationType", { length: 80 }).notNull(),
  payload: text("payload").notNull(),
  syncStatus: mysqlEnum("syncStatus", ["PENDING_SYNC", "SYNCING", "SYNCED", "SYNC_FAILED"]).default("PENDING_SYNC").notNull(),
  retryCount: int("retryCount").default(0).notNull(),
  lastError: text("lastError"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  syncedAt: timestamp("syncedAt"),
});
