CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actor` int NOT NULL,
	`role` varchar(40) NOT NULL,
	`action` varchar(80) NOT NULL,
	`entity` varchar(80) NOT NULL,
	`entityId` varchar(64) NOT NULL,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bookings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookingReference` varchar(32) NOT NULL,
	`farmerId` int NOT NULL,
	`centreId` int NOT NULL,
	`timeSlotId` int NOT NULL,
	`crop` varchar(60) NOT NULL,
	`status` enum('BOOKED','ARRIVED','IN_QUEUE','WEIGHMENT_PENDING','QUALITY_PENDING','PAYMENT_PENDING','COMPLETED','CANCELLED') NOT NULL DEFAULT 'BOOKED',
	`token` varchar(20) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bookings_id` PRIMARY KEY(`id`),
	CONSTRAINT `bookings_bookingReference_unique` UNIQUE(`bookingReference`)
);
--> statement-breakpoint
CREATE TABLE `farmer_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`farmerId` varchar(32) NOT NULL,
	`village` varchar(120) NOT NULL,
	`district` varchar(120) NOT NULL,
	`state` varchar(120) NOT NULL,
	`preferredLanguage` varchar(10) NOT NULL DEFAULT 'en',
	`crops` text,
	`farmDetails` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `farmer_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `farmer_profiles_farmerId_unique` UNIQUE(`farmerId`)
);
--> statement-breakpoint
CREATE TABLE `identity_verifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`provider` varchar(80) NOT NULL,
	`status` enum('PENDING','OTP_SENT','VERIFIED','FAILED') NOT NULL DEFAULT 'PENDING',
	`verificationReference` varchar(64),
	`maskedReference` varchar(32),
	`verifiedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `identity_verifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `msp_rates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`crop` varchar(60) NOT NULL,
	`ratePerQuintal` decimal(12,2) NOT NULL,
	`effectiveFrom` timestamp NOT NULL DEFAULT (now()),
	`updatedBy` int,
	CONSTRAINT `msp_rates_id` PRIMARY KEY(`id`),
	CONSTRAINT `msp_rates_crop_unique` UNIQUE(`crop`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`message` text NOT NULL,
	`channel` enum('IN_APP','SMS','EMAIL','VOICE') NOT NULL DEFAULT 'IN_APP',
	`status` enum('UNREAD','READ','FAILED') NOT NULL DEFAULT 'UNREAD',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookingId` int NOT NULL,
	`farmerId` int NOT NULL,
	`eligibleQuantity` decimal(10,2) NOT NULL,
	`mspPerQuintal` decimal(12,2) NOT NULL,
	`grossAmount` decimal(14,2) NOT NULL,
	`deductionAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`finalAmount` decimal(14,2) NOT NULL,
	`status` enum('PAYMENT_PENDING','PROCESSING','PAID','FAILED') NOT NULL DEFAULT 'PAYMENT_PENDING',
	`provider` varchar(80) NOT NULL DEFAULT 'MockPaymentProvider',
	`transactionReference` varchar(64),
	`processedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `payments_id` PRIMARY KEY(`id`),
	CONSTRAINT `payments_bookingId_unique` UNIQUE(`bookingId`)
);
--> statement-breakpoint
CREATE TABLE `procurement_centres` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`location` varchar(200) NOT NULL,
	`district` varchar(120) NOT NULL,
	`state` varchar(120) NOT NULL,
	`capacityPerDay` int NOT NULL,
	`operatingHours` varchar(80) NOT NULL,
	`supportedCrops` text,
	`status` enum('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `procurement_centres_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quality_assessments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookingId` int NOT NULL,
	`moisturePct` decimal(5,2) NOT NULL,
	`foreignMatterPct` decimal(5,2) NOT NULL,
	`damagedGrainPct` decimal(5,2) NOT NULL,
	`result` enum('ACCEPTED','ACCEPTED_WITH_DEDUCTION','REJECTED') NOT NULL,
	`deductionPct` decimal(5,2) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quality_assessments_id` PRIMARY KEY(`id`),
	CONSTRAINT `quality_assessments_bookingId_unique` UNIQUE(`bookingId`)
);
--> statement-breakpoint
CREATE TABLE `queue_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookingId` int NOT NULL,
	`centreId` int NOT NULL,
	`position` int NOT NULL,
	`status` enum('WAITING','CALLED','CHECKED_IN','COMPLETED') NOT NULL DEFAULT 'WAITING',
	`estimatedWaitMinutes` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `queue_entries_id` PRIMARY KEY(`id`),
	CONSTRAINT `queue_entries_bookingId_unique` UNIQUE(`bookingId`)
);
--> statement-breakpoint
CREATE TABLE `sync_transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`localTransactionId` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`centreId` int,
	`operationType` varchar(80) NOT NULL,
	`payload` text NOT NULL,
	`syncStatus` enum('PENDING_SYNC','SYNCING','SYNCED','SYNC_FAILED') NOT NULL DEFAULT 'PENDING_SYNC',
	`retryCount` int NOT NULL DEFAULT 0,
	`lastError` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`syncedAt` timestamp,
	CONSTRAINT `sync_transactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `sync_transactions_localTransactionId_unique` UNIQUE(`localTransactionId`)
);
--> statement-breakpoint
CREATE TABLE `time_slots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`centreId` int NOT NULL,
	`crop` varchar(60) NOT NULL,
	`slotDate` varchar(20) NOT NULL,
	`startTime` varchar(10) NOT NULL,
	`endTime` varchar(10) NOT NULL,
	`capacity` int NOT NULL,
	`booked` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `time_slots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weighment_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookingId` int NOT NULL,
	`grossKg` decimal(10,2) NOT NULL,
	`tareKg` decimal(10,2) NOT NULL,
	`netKg` decimal(10,2) NOT NULL,
	`netQuintals` decimal(10,2) NOT NULL,
	`provider` varchar(80) NOT NULL DEFAULT 'MockWeighbridgeProvider',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `weighment_records_id` PRIMARY KEY(`id`),
	CONSTRAINT `weighment_records_bookingId_unique` UNIQUE(`bookingId`)
);
--> statement-breakpoint
CREATE INDEX `audit_logs_entity_idx` ON `audit_logs` (`entity`,`entityId`);--> statement-breakpoint
CREATE INDEX `bookings_farmer_status_idx` ON `bookings` (`farmerId`,`status`);--> statement-breakpoint
CREATE INDEX `bookings_centre_status_idx` ON `bookings` (`centreId`,`status`);--> statement-breakpoint
CREATE INDEX `farmer_profiles_user_idx` ON `farmer_profiles` (`userId`);--> statement-breakpoint
CREATE INDEX `identity_verifications_user_idx` ON `identity_verifications` (`userId`);--> statement-breakpoint
CREATE INDEX `time_slots_centre_date_idx` ON `time_slots` (`centreId`,`slotDate`);