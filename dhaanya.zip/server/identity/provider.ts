import { randomInt } from "node:crypto";

export type VerificationStatus = "PENDING" | "OTP_SENT" | "VERIFIED" | "FAILED" | "EXPIRED";
export type VerificationRecord = { provider: "DEMO"; status: VerificationStatus; maskedReference?: string; verificationReference?: string; verifiedAt?: string; demoOtp?: string };

export interface IdentityVerificationProvider {
  startVerification(maskedReference: string): Promise<VerificationRecord>;
  verifyOTP(otp: string): Promise<VerificationRecord>;
  getVerificationStatus(reference: string): Promise<VerificationRecord>;
}

export class MockIdentityVerificationProvider implements IdentityVerificationProvider {
  async startVerification(maskedReference: string): Promise<VerificationRecord> {
    const lastFour = maskedReference.replace(/\D/g, "").slice(-4);
    return { provider: "DEMO", status: "OTP_SENT", maskedReference: `XXXX XXXX ${lastFour}`, demoOtp: "123456" };
  }

  async verifyOTP(otp: string): Promise<VerificationRecord> {
    if (otp !== "123456") return { provider: "DEMO", status: "FAILED" };
    return { provider: "DEMO", status: "VERIFIED", verificationReference: `DHA-VER-2026-${randomInt(1000, 10000)}`, verifiedAt: new Date().toISOString() };
  }

  async getVerificationStatus(reference: string): Promise<VerificationRecord> {
    return { provider: "DEMO", status: reference.startsWith("DHA-VER-") ? "VERIFIED" : "FAILED", verificationReference: reference };
  }
}

export class UIDAIIdentityProvider implements IdentityVerificationProvider {
  async startVerification(): Promise<VerificationRecord> { throw new Error("UIDAI provider is disabled until authorized server-side configuration is supplied."); }
  async verifyOTP(): Promise<VerificationRecord> { throw new Error("UIDAI provider is disabled until authorized server-side configuration is supplied."); }
  async getVerificationStatus(): Promise<VerificationRecord> { throw new Error("UIDAI provider is disabled until authorized server-side configuration is supplied."); }
}

const configuredProvider = process.env.IDENTITY_PROVIDER ?? "MOCK";
export const identityVerificationProvider: IdentityVerificationProvider = configuredProvider === "UIDAI_SANDBOX" || configuredProvider === "UIDAI_PRODUCTION" ? new UIDAIIdentityProvider() : new MockIdentityVerificationProvider();
