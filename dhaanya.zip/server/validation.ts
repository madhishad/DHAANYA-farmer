import { z } from "zod";

const namePattern = /^[\p{L}\p{M}]+(?:[ .'-][\p{L}\p{M}]+)*$/u;
const mobilePattern = /^[6-9]\d{9}$/;
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const pincodePattern = /^\d{6}$/;

export const supportedLanguages = ["en", "hi", "ta", "pa"] as const;
export const cropCodes = ["SOYBEAN", "WHEAT", "PADDY", "MAIZE", "GROUNDNUT", "COTTON", "SUGARCANE"] as const;
export const states = ["Madhya Pradesh", "Punjab", "Tamil Nadu", "Haryana"] as const;
export const districtsByState = {
  "Madhya Pradesh": ["Sehore", "Bhopal", "Indore"],
  Punjab: ["Ludhiana", "Patiala", "Amritsar"],
  "Tamil Nadu": ["Thanjavur", "Madurai", "Salem"],
  Haryana: ["Hisar", "Karnal", "Rohtak"],
} as const;

export const farmerRegistrationSchema = z.object({
  name: z.string().trim().min(2).max(80).refine((value) => namePattern.test(value) && !/(.)\1\1\1/.test(value), "Enter a valid name using letters, spaces, hyphens or apostrophes."),
  mobile: z.string().trim().regex(mobilePattern, "Enter a valid 10-digit Indian mobile number."),
  email: z.string().trim().max(320).refine((value) => value === "" || emailPattern.test(value), "Enter a valid email address or leave it empty."),
  state: z.enum(states),
  district: z.string().trim().min(2).max(120),
  village: z.string().trim().min(2).max(120).regex(/^[\p{L}\p{M}0-9 .'-]+$/u, "Enter a valid village name."),
  landRecord: z.string().trim().regex(/^LR-[A-Z0-9]{6,12}$/, "Enter a valid land record number."),
  crop: z.enum(cropCodes),
  area: z.number().positive().max(100000),
  preferredLanguage: z.enum(supportedLanguages),
  pincode: z.string().trim().regex(pincodePattern, "Enter a valid 6-digit pincode.").optional().or(z.literal("")),
});

export type FarmerRegistrationInput = z.infer<typeof farmerRegistrationSchema>;
export function nextFarmerId(sequence = 1) { return `DHA-F-${new Date().getFullYear()}-${String(sequence).padStart(3, "0")}`; }
