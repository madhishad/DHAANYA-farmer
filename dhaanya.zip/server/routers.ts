import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { identityVerificationProvider } from "./identity/provider";
import { landVerificationProvider } from "./land/provider";
import { getDb, getCurrentBooking, getFarmerProfile, upsertFarmerProfile, upsertUser } from "./db";
import { identityVerifications } from "../drizzle/schema";
import { districtsByState, farmerRegistrationSchema, nextFarmerId } from "./validation";

const issuedFarmerIds = new Set<string>();
const notificationState = new Map<string, Set<string>>();

type DemoFarmer = { farmerId: string; name: string; mobile: string; email: string; state: string; district: string; village: string; preferredLanguage: string; crop: string; area: number; pincode: string };
const farmerProfiles = new Map<string, DemoFarmer>([["farmer@dhaanya.demo", { farmerId: "DHA-F-2026-001", name: "Sita Devi", mobile: "9876543210", email: "farmer@dhaanya.demo", state: "Madhya Pradesh", district: "Sehore", village: "Bargaon", preferredLanguage: "en", crop: "SOYBEAN", area: 4.5, pincode: "466001" }]]);
const farmerBookings = new Map<string, { bookingReference: string; farmerName: string; farmerId: string; centreId: string; centreName: string; location: string; crop: string; date: string; startTime: string; token: string; status: "BOOKED" | "IN_QUEUE"; position: number; estimatedWaitMinutes: number }>();
const availableCentres = [
  { id: "BARGAON-PC-001", name: "Bargaon Procurement Centre", location: "Main Market Road, Bargaon", district: "Sehore", state: "Madhya Pradesh", distanceKm: 2.4, status: "ACTIVE" as const, availableSlots: 42, currentQueue: 18, estimatedWaitMinutes: 22, openingHours: "08:00 AM – 05:00 PM" },
  { id: "SEHORE-MANDI-002", name: "Sehore Mandi", location: "Mandi Road, Sehore", district: "Sehore", state: "Madhya Pradesh", distanceKm: 14, status: "ACTIVE" as const, availableSlots: 28, currentQueue: 31, estimatedWaitMinutes: 42, openingHours: "08:00 AM – 05:00 PM" },
  { id: "ASHTA-PC-003", name: "Ashta Procurement Centre", location: "Grain Market, Ashta", district: "Sehore", state: "Madhya Pradesh", distanceKm: 27, status: "ACTIVE" as const, availableSlots: 65, currentQueue: 11, estimatedWaitMinutes: 15, openingHours: "08:30 AM – 04:30 PM" },
];

const demoQueue = [
  { id: 1, token: "A-024", name: "Sita Devi", crop: "Soybean", quantity: "18.5 qtl", status: "Arrived" },
  { id: 2, token: "A-025", name: "Mohan Singh", crop: "Soybean", quantity: "24 qtl", status: "Waiting" },
  { id: 3, token: "A-026", name: "Kavita Bai", crop: "Wheat", quantity: "16 qtl", status: "Waiting" },
  { id: 4, token: "A-027", name: "Raju Yadav", crop: "Soybean", quantity: "31 qtl", status: "Quality" },
] as const;

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    demoLogin: publicProcedure.input(z.object({ role: z.enum(["farmer", "centre_officer", "admin", "village_assistant"]), identifier: z.string().min(3), password: z.string().min(1) })).mutation(({ input }) => {
      const expected = {
        farmer: { identifier: "farmer@dhaanya.demo", password: "password123" },
        centre_officer: { identifier: "BARGAON-PC-001", password: "password123" },
        admin: { identifier: "admin@dhaanya.demo", password: "password123" },
        village_assistant: { identifier: "assistant@dhaanya.demo", password: "password123" },
      } as const;
      const account = expected[input.role];
      if (input.identifier !== account.identifier || input.password !== account.password) throw new Error("Invalid demo credentials");
      return { authenticated: true as const, role: input.role, identifier: input.identifier, centre: input.role === "centre_officer" ? "BARGAON-PC-001" : undefined, signedInAt: new Date().toISOString() };
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  farmer: router({
    register: publicProcedure.input(farmerRegistrationSchema).mutation(({ input }) => {
      const districts = districtsByState[input.state] as readonly string[];
      if (!districts.includes(input.district)) throw new Error("Choose a valid district for the selected state.");
      let sequence = issuedFarmerIds.size + 1;
      let farmerId = nextFarmerId(sequence);
      while (issuedFarmerIds.has(farmerId)) { sequence += 1; farmerId = nextFarmerId(sequence); }
      issuedFarmerIds.add(farmerId);
      const profile = { farmerId, ...input, crop: input.crop, status: "REGISTERED" as const };
      farmerProfiles.set(input.email || input.mobile, { farmerId, name: input.name, mobile: input.mobile, email: input.email || "", state: input.state, district: input.district, village: input.village, preferredLanguage: input.preferredLanguage, crop: input.crop, area: input.area, pincode: input.pincode ?? "" });
      void upsertUser({ openId: `demo-${input.email || input.mobile}`, name: input.name, email: input.email || null, role: "farmer", loginMethod: "demo" }).then(async () => { const db = await getDb(); if (db) { const user = await (await import("./db")).getUserByOpenId(`demo-${input.email || input.mobile}`); if (user) await upsertFarmerProfile({ userId: user.id, farmerId, name: input.name, mobile: input.mobile, village: input.village, district: input.district, state: input.state, preferredLanguage: input.preferredLanguage, crops: input.crop, farmDetails: JSON.stringify({ name: input.name, mobile: input.mobile, landRecord: input.landRecord, area: input.area, pincode: input.pincode }) }); } }).catch(() => undefined);
      return profile;
    }),
  }),
  profile: router({
    get: publicProcedure.input(z.object({ farmerKey: z.string().min(3) })).query(async ({ input }) => {
      const stored = farmerProfiles.get(input.farmerKey) ?? farmerProfiles.get("farmer@dhaanya.demo");
      if (stored) return stored;
      return undefined;
    }),
  }),
  booking: router({
    centres: publicProcedure.input(z.object({ farmerKey: z.string().optional() }).optional()).query(() => availableCentres),
    current: publicProcedure.input(z.object({ farmerKey: z.string().min(3) })).query(async ({ input }) => {
      const inMemory = farmerBookings.get(input.farmerKey);
      if (inMemory) return inMemory;
      return undefined;
    }),
    create: publicProcedure.input(z.object({ farmerKey: z.string().min(3), centreId: z.string().min(3), crop: z.string().min(2), date: z.string().min(8), startTime: z.string().min(4) })).mutation(({ input }) => {
      const profile = farmerProfiles.get(input.farmerKey) ?? farmerProfiles.get("farmer@dhaanya.demo")!;
      const centre = availableCentres.find((item) => item.id === input.centreId);
      if (!centre) throw new Error("Selected procurement centre is unavailable.");
      const existing = farmerBookings.get(input.farmerKey);
      if (existing) return { ...existing, duplicate: true as const };
      const booking = { bookingReference: `DHA-BOOK-${Date.now().toString().slice(-8)}`, farmerName: profile.name, farmerId: profile.farmerId, centreId: centre.id, centreName: centre.name, location: centre.location, crop: input.crop, date: input.date, startTime: input.startTime, token: `A-${String(24 + farmerBookings.size).padStart(3, "0")}`, status: "BOOKED" as const, position: centre.currentQueue + 1, estimatedWaitMinutes: centre.estimatedWaitMinutes };
      farmerBookings.set(input.farmerKey, booking);
      return { ...booking, duplicate: false as const };
    }),
  }),
  identity: router({
    start: publicProcedure.input(z.object({ maskedReference: z.string().min(4).max(64), consent: z.literal(true) })).mutation(async ({ input, ctx }) => {
      const result = await identityVerificationProvider.startVerification(input.maskedReference);
      if (ctx.user) {
        const db = await getDb();
        if (db) await db.insert(identityVerifications).values({ userId: ctx.user.id, provider: result.provider, status: result.status, maskedReference: result.maskedReference, consentTimestamp: new Date() });
      }
      return result;
    }),
    verify: publicProcedure.input(z.object({ otp: z.string().length(6) })).mutation(async ({ input, ctx }) => {
      const result = await identityVerificationProvider.verifyOTP(input.otp);
      if (ctx.user) {
        const db = await getDb();
        if (db) await db.insert(identityVerifications).values({ userId: ctx.user.id, provider: result.provider, status: result.status, verificationReference: result.verificationReference, verifiedAt: result.verifiedAt ? new Date(result.verifiedAt) : undefined });
      }
      return result;
    }),
    status: publicProcedure.input(z.object({ reference: z.string().min(8).max(64) })).query(({ input }) => identityVerificationProvider.getVerificationStatus(input.reference)),
  }),
  land: router({
    verify: publicProcedure.input(z.object({ landRecordNumber: z.string().min(3).max(32), farmerName: z.string().optional() })).mutation(({ input }) => landVerificationProvider.verifyLandRecord(input.landRecordNumber, input.farmerName)),
    details: publicProcedure.input(z.object({ reference: z.string().min(3).max(32) })).query(({ input }) => landVerificationProvider.getLandDetails(input.reference)),
    ownership: publicProcedure.input(z.object({ reference: z.string().min(3).max(32) })).query(({ input }) => landVerificationProvider.getOwnershipStatus(input.reference)),
  }),
  procurement: router({
    dashboard: publicProcedure.query(() => ({
      season: "Kharif 2026",
      centre: "Bargaon Procurement Centre",
      msp: { soybean: 5328, wheat: 2275 },
      queue: demoQueue,
      sync: { state: "online", lastSyncedAt: new Date().toISOString() },
    })),
    checkIn: publicProcedure
      .input(z.object({ queueId: z.number().int().positive() }))
      .mutation(({ input }) => ({
        success: true,
        queueId: input.queueId,
        nextStage: "weighment" as const,
        checkedInAt: new Date().toISOString(),
      })),
    weighment: publicProcedure.input(z.object({ bookingId: z.string(), grossKg: z.number().nonnegative(), tareKg: z.number().nonnegative() })).mutation(({ input }) => {
      const netKg = Math.max(0, input.grossKg - input.tareKg);
      return { bookingId: input.bookingId, grossKg: input.grossKg, tareKg: input.tareKg, netKg, netQuintals: Number((netKg / 100).toFixed(2)), status: "WEIGHMENT_COMPLETED" as const, provider: "MockWeighbridgeProvider" as const };
    }),
    quality: publicProcedure.input(z.object({ bookingId: z.string(), moisturePct: z.number().min(0).max(100), foreignMatterPct: z.number().min(0).max(100), damagedGrainPct: z.number().min(0).max(100) })).mutation(({ input }) => {
      const deductionPct = input.moisturePct > 14 ? 2 : 0;
      return { bookingId: input.bookingId, status: deductionPct > 0 ? "ACCEPTED_WITH_DEDUCTION" as const : "ACCEPTED" as const, deductionPct, transparentNote: deductionPct > 0 ? "Moisture above 14% triggers the configured demo deduction." : "Within configured FAQ thresholds." };
    }),
    calculateMsp: publicProcedure.input(z.object({ crop: z.enum(["paddy", "wheat", "maize", "groundnut", "cotton", "sugarcane"]), eligibleQuintals: z.number().nonnegative(), deductionAmount: z.number().nonnegative().default(0) })).query(({ input }) => {
      const rates = { paddy: 2300, wheat: 2275, maize: 2200, groundnut: 6783, cotton: 7121, sugarcane: 340 } as const;
      const grossAmount = Number((input.eligibleQuintals * rates[input.crop]).toFixed(2));
      return { crop: input.crop, mspPerQuintal: rates[input.crop], eligibleQuintals: input.eligibleQuintals, grossAmount, deductionAmount: input.deductionAmount, finalPayableAmount: Number((grossAmount - input.deductionAmount).toFixed(2)) };
    }),
    createPayment: publicProcedure.input(z.object({ bookingId: z.string(), farmerName: z.string(), finalAmount: z.number().nonnegative() })).mutation(({ input }) => ({
      bookingId: input.bookingId,
      farmerName: input.farmerName,
      amount: input.finalAmount,
      status: "PAID" as const,
      provider: "MockPaymentProvider" as const,
      demoReference: `DHA-PAY-2026-${Date.now().toString().slice(-4)}`,
      processedAt: new Date().toISOString(),
    })),
  }),
  payments: router({
    history: publicProcedure.input(z.object({ farmerKey: z.string().min(1).default("demo-farmer") }).optional()).query(() => ({
      demo: true,
      currency: "INR",
      totalReceived: 112040,
      records: [
        { id: "pay-0261", lot: "LOT-0261", date: "2026-08-18", crop: "SOYBEAN", quantityQuintals: 18.5, amount: 42680, status: "PAID" as const, transactionReference: "DHA-PAY-2026-0261" },
        { id: "pay-0208", lot: "LOT-0208", date: "2026-08-04", crop: "SOYBEAN", quantityQuintals: 12, amount: 29040, status: "PAID" as const, transactionReference: "DHA-PAY-2026-0208" },
        { id: "pay-0142", lot: "LOT-0142", date: "2026-07-26", crop: "WHEAT", quantityQuintals: 12, amount: 40320, status: "PAID" as const, transactionReference: "DHA-PAY-2026-0142" },
      ],
    })),
  }),
  centre: router({
    dashboard: publicProcedure.query(() => ({
      todayFarmers: demoQueue.length,
      todayBookings: demoQueue.length,
      waitingFarmers: demoQueue.filter((item) => item.status === "Waiting").length,
      currentToken: demoQueue[0]?.token ?? "—",
      completedProcurement: 11,
      pendingWeighments: 24,
      pendingQualityAssessments: 18,
      pendingPayments: 7,
      averageWaitingMinutes: 22,
      totalQuintals: 312.5,
    })),
    details: publicProcedure.query(() => ({
      id: "BARGAON-PC-001",
      name: "Bargaon Procurement Centre",
      address: "Main Market Road, Bargaon, Sehore, Madhya Pradesh 466001",
      village: "Bargaon",
      district: "Sehore",
      state: "Madhya Pradesh",
      coordinates: { lat: 23.2032, lng: 77.0846 },
      openingHours: "08:00 AM – 05:00 PM",
      contact: "1800-XXX-XXXX",
      capacityPerDay: 120,
      availableSlots: 42,
      currentQueue: 18,
      estimatedWaitMinutes: 22,
      farmerToken: "A-024",
      farmersAhead: 1,
      traffic: { status: "UNAVAILABLE" as const, isLive: false },
      provider: "DEMO CENTRE DIRECTORY",
    })),
  }),
  notifications: router({
    list: publicProcedure.input(z.object({ userKey: z.string().min(1).default("demo-farmer") }).optional()).query(({ input }) => {
      const userKey = input?.userKey ?? "demo-farmer";
      const read = notificationState.get(userKey) ?? new Set<string>();
      return [
        { id: "n-1", type: "BOOKING_CONFIRMED" as const, destination: "/farmer/book", occurredAt: "2026-09-24T06:45:00.000Z", status: read.has("n-1") ? "READ" as const : "UNREAD" as const },
        { id: "n-2", type: "TOKEN_APPROACHING" as const, destination: "/farmer/queue", occurredAt: "2026-09-24T07:10:00.000Z", status: read.has("n-2") ? "READ" as const : "UNREAD" as const },
        { id: "n-3", type: "PAYMENT_PROCESSED" as const, destination: "/farmer/payments", occurredAt: "2026-09-24T07:35:00.000Z", status: read.has("n-3") ? "READ" as const : "UNREAD" as const },
        { id: "n-4", type: "OFFLINE_SYNC" as const, destination: "/farmer/dashboard", occurredAt: "2026-09-24T08:00:00.000Z", status: read.has("n-4") ? "READ" as const : "UNREAD" as const },
      ];
    }),
    markRead: publicProcedure.input(z.object({ userKey: z.string().min(1), notificationId: z.string().min(1) })).mutation(({ input }) => { const read = notificationState.get(input.userKey) ?? new Set<string>(); read.add(input.notificationId); notificationState.set(input.userKey, read); return { success: true as const }; }),
    markAllRead: publicProcedure.input(z.object({ userKey: z.string().min(1) })).mutation(({ input }) => { const read = notificationState.get(input.userKey) ?? new Set<string>(); ["n-1", "n-2", "n-3", "n-4"].forEach((id) => read.add(id)); notificationState.set(input.userKey, read); return { success: true as const }; }),
    pushSupport: publicProcedure.query(() => ({ supported: typeof process !== "undefined", configured: false, message: "Push notifications require a configured browser push provider." })),
  }),
  sync: router({
    submit: publicProcedure.input(z.object({ deviceId: z.string(), transactions: z.array(z.object({ localTransactionId: z.string(), operationType: z.string(), payload: z.unknown() })) })).mutation(({ input }) => ({
      deviceId: input.deviceId,
      synced: input.transactions.map((transaction) => transaction.localTransactionId),
      failed: [],
      conflicts: [],
    })),
  }),
});

export type AppRouter = typeof appRouter;
