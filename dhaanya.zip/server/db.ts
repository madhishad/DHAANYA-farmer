import { and, desc, eq, inArray, ne, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, bookings, farmerProfiles, procurementCentres, queueEntries, timeSlots, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  (['name', 'email', 'loginMethod'] as const).forEach((field) => { if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; } });
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; } else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return result[0]; }

export type FarmerProfileInput = { userId: number; farmerId: string; name: string; mobile?: string; village: string; district: string; state: string; preferredLanguage: string; crops?: string; farmDetails?: string };
export async function upsertFarmerProfile(input: FarmerProfileInput) {
  const db = await getDb();
  if (!db) return undefined;
  const existing = await db.select().from(farmerProfiles).where(eq(farmerProfiles.userId, input.userId)).limit(1);
  if (existing[0]) { await db.update(farmerProfiles).set({ farmerId: input.farmerId, village: input.village, district: input.district, state: input.state, preferredLanguage: input.preferredLanguage, crops: input.crops, farmDetails: JSON.stringify({ ...(input.farmDetails ? JSON.parse(input.farmDetails) : {}), name: input.name, mobile: input.mobile }) }).where(eq(farmerProfiles.userId, input.userId)); return (await db.select().from(farmerProfiles).where(eq(farmerProfiles.userId, input.userId)).limit(1))[0]; }
  await db.insert(farmerProfiles).values({ userId: input.userId, farmerId: input.farmerId, village: input.village, district: input.district, state: input.state, preferredLanguage: input.preferredLanguage, crops: input.crops, farmDetails: JSON.stringify({ name: input.name, mobile: input.mobile }) });
  return (await db.select().from(farmerProfiles).where(eq(farmerProfiles.userId, input.userId)).limit(1))[0];
}

export async function getFarmerProfile(userId: number) { const db = await getDb(); if (!db) return undefined; const result = await db.select({ profile: farmerProfiles, user: users }).from(farmerProfiles).innerJoin(users, eq(farmerProfiles.userId, users.id)).where(eq(farmerProfiles.userId, userId)).limit(1); const row = result[0]; if (!row) return undefined; let extras: { name?: string; mobile?: string } = {}; try { extras = row.profile.farmDetails ? JSON.parse(row.profile.farmDetails) : {}; } catch { /* safe fallback */ } return { ...row.profile, name: extras.name ?? row.user.name ?? "", mobile: extras.mobile ?? "", email: row.user.email ?? "" }; }

export async function listActiveCentres() { const db = await getDb(); if (!db) return []; const centres = await db.select().from(procurementCentres).where(eq(procurementCentres.status, "ACTIVE")); return centres; }
export async function listAvailableSlots() { const db = await getDb(); if (!db) return []; return db.select({ slot: timeSlots, centre: procurementCentres }).from(timeSlots).innerJoin(procurementCentres, eq(timeSlots.centreId, procurementCentres.id)).where(and(eq(procurementCentres.status, "ACTIVE"), sql`${timeSlots.booked} < ${timeSlots.capacity}`)); }
export async function getCurrentBooking(farmerId: number) { const db = await getDb(); if (!db) return undefined; const result = await db.select({ booking: bookings, slot: timeSlots, centre: procurementCentres, queue: queueEntries }).from(bookings).innerJoin(timeSlots, eq(bookings.timeSlotId, timeSlots.id)).innerJoin(procurementCentres, eq(bookings.centreId, procurementCentres.id)).leftJoin(queueEntries, eq(queueEntries.bookingId, bookings.id)).where(and(eq(bookings.farmerId, farmerId), inArray(bookings.status, ["BOOKED", "ARRIVED", "IN_QUEUE", "WEIGHMENT_PENDING", "QUALITY_PENDING", "PAYMENT_PENDING"]))).orderBy(desc(bookings.createdAt)).limit(1); return result[0]; }
export async function findDuplicateBooking(farmerId: number, slotId: number, crop: string) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(bookings).where(and(eq(bookings.farmerId, farmerId), eq(bookings.timeSlotId, slotId), eq(bookings.crop, crop), ne(bookings.status, "CANCELLED"))).limit(1); return result[0]; }
