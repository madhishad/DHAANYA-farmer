export type LandVerificationRecord = { provider: "MOCK LAND RECORDS PROVIDER"; status: "VERIFIED" | "FAILED"; landRecordNumber: string; village?: string; district?: string; registeredFarmer?: string; cultivableAreaAcres?: number; providerReference?: string };
export interface LandVerificationProvider { verifyLandRecord(landRecordNumber: string, farmerName?: string): Promise<LandVerificationRecord>; getLandDetails(reference: string): Promise<LandVerificationRecord>; getOwnershipStatus(reference: string): Promise<LandVerificationRecord>; }
export class MockLandRecordsProvider implements LandVerificationProvider {
  async verifyLandRecord(landRecordNumber: string, farmerName?: string) { const normalized = landRecordNumber.trim().toUpperCase(); if (!/^LR-[A-Z0-9]{6,12}$/.test(normalized)) return { provider: "MOCK LAND RECORDS PROVIDER" as const, status: "FAILED" as const, landRecordNumber: normalized }; return { provider: "MOCK LAND RECORDS PROVIDER" as const, status: "VERIFIED" as const, landRecordNumber: normalized, village: "Bargaon", district: "Sehore", registeredFarmer: farmerName || "Demo Farmer", cultivableAreaAcres: 4.2, providerReference: `MOCK-LAND-${normalized.slice(-6)}` }; }
  async getLandDetails(reference: string) { return this.verifyLandRecord(reference); }
  async getOwnershipStatus(reference: string) { return this.verifyLandRecord(reference); }
}
export const landVerificationProvider: LandVerificationProvider = new MockLandRecordsProvider();
