import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("procurement router", () => {
  it("authenticates the seeded centre officer account through the backend", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.auth.demoLogin({ role: "centre_officer", identifier: "BARGAON-PC-001", password: "password123" });
    expect(result).toMatchObject({ authenticated: true, role: "centre_officer", centre: "BARGAON-PC-001" });
  });

  it("verifies seeded land records through the mock provider boundary", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.land.verify({ landRecordNumber: "LR-ABC123", farmerName: "Sita Devi" });
    expect(result).toMatchObject({ status: "VERIFIED", village: "Bargaon", district: "Sehore", cultivableAreaAcres: 4.2 });
    expect(result.provider).toBe("MOCK LAND RECORDS PROVIDER");
  });

  it("returns a transparent dashboard snapshot for the centre", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.procurement.dashboard();

    expect(result.centre).toBe("Bargaon Procurement Centre");
    expect(result.msp.soybean).toBe(5328);
    expect(result.queue).toHaveLength(4);
    expect(result.queue[0]).toMatchObject({ token: "A-024", status: "Arrived" });
  });

  it("moves a queue token to the weighment stage after check-in", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.procurement.checkIn({ queueId: 1 });

    expect(result).toMatchObject({ success: true, queueId: 1, nextStage: "weighment" });
    expect(Number.isNaN(Date.parse(result.checkedInAt))).toBe(false);
  });

  it("calculates net quantity and quintals without allowing negative weight", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.procurement.weighment({ bookingId: "B-024", grossKg: 1250, tareKg: 50 });

    expect(result.netKg).toBe(1200);
    expect(result.netQuintals).toBe(12);
    expect(result.provider).toBe("MockWeighbridgeProvider");
  });

  it("keeps quality deductions transparent and calculates MSP on the server contract", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const quality = await caller.procurement.quality({ bookingId: "B-024", moisturePct: 16, foreignMatterPct: 1, damagedGrainPct: 1 });
    const msp = await caller.procurement.calculateMsp({ crop: "maize", eligibleQuintals: 12.5, deductionAmount: 0 });

    expect(quality.status).toBe("ACCEPTED_WITH_DEDUCTION");
    expect(quality.deductionPct).toBe(2);
    expect(msp.grossAmount).toBe(27500);
    expect(msp.finalPayableAmount).toBe(27500);
  });

  it("returns a demo payment reference only after the payment contract is called", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.procurement.createPayment({ bookingId: "B-024", farmerName: "Sita Devi", finalAmount: 27500 });

    expect(result.status).toBe("PAID");
    expect(result.provider).toBe("MockPaymentProvider");
    expect(result.demoReference).toMatch(/^DHA-PAY-2026-/);
  });

  it("verifies the documented mock identity OTP and returns a safe reference", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const started = await caller.identity.start({ maskedReference: "4821", consent: true });
    const verified = await caller.identity.verify({ otp: started.demoOtp });

    expect(started.maskedReference).toBe("XXXX XXXX 4821");
    expect(verified.status).toBe("VERIFIED");
    expect(verified.verificationReference).toMatch(/^DHA-VER-2026-/);
  });

  it("rejects an invalid demo OTP without exposing identity data", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const failed = await caller.identity.verify({ otp: "000000" });

    expect(failed).toMatchObject({ provider: "DEMO", status: "FAILED" });
    expect(failed).not.toHaveProperty("maskedReference");
    expect(failed).not.toHaveProperty("demoOtp");
  });

  it("returns verification status from a safe reference", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const status = await caller.identity.status({ reference: "DHA-VER-2026-4821" });

    expect(status).toMatchObject({ provider: "DEMO", status: "VERIFIED", verificationReference: "DHA-VER-2026-4821" });
  });

  it("rejects invalid farmer registration data at the backend boundary", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(caller.farmer.register({ name: "xcxcvndjfgh", mobile: "123", email: "abc@", state: "Madhya Pradesh", district: "Sehore", village: "", landRecord: "bad", crop: "SOYBEAN", area: 0, preferredLanguage: "ta", pincode: "123" })).rejects.toThrow();
  });

  it("generates an immutable farmer ID instead of accepting one from the client", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.farmer.register({ name: "ரமேஷ் குமார்", mobile: "9876543210", email: "", state: "Tamil Nadu", district: "Thanjavur", village: "Kumbakonam", landRecord: "LR-ABC123", crop: "SOYBEAN", area: 2.5, preferredLanguage: "ta", pincode: "613001" });
    expect(result.farmerId).toMatch(/^DHA-F-\d{4}-\d{3}$/);
    expect(result.status).toBe("REGISTERED");
  });

  it("returns assigned centre details without claiming live traffic", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.centre.details();
    expect(result.id).toBe("BARGAON-PC-001");
    expect(result.traffic).toMatchObject({ isLive: false, status: "UNAVAILABLE" });
    expect(result.farmerToken).toBe("A-024");
  });

  it("supports localized-safe notification read state and backend payment history", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const before = await caller.notifications.list({ userKey: "test-farmer" });
    expect(before.filter((item) => item.status === "UNREAD")).toHaveLength(4);
    await caller.notifications.markRead({ userKey: "test-farmer", notificationId: "n-1" });
    const after = await caller.notifications.list({ userKey: "test-farmer" });
    expect(after.find((item) => item.id === "n-1")?.status).toBe("READ");
    const payments = await caller.payments.history({ farmerKey: "test-farmer" });
    expect(payments.records[0]).toMatchObject({ status: "PAID", transactionReference: "DHA-PAY-2026-0261" });
  });
});
